const DEFAULT_API = 'http://127.0.0.1:8110';
const FLOW_VIDEO_TIMEOUT_MS = 15 * 60 * 1000;
// Conservative provider rate limits. Fixed pauses avoid burst traffic and
// protect credits; they are not intended to imitate a person or bypass Flow's
// abuse controls.
const AFTER_IMAGE_COOLDOWN_MS = 8 * 60 * 1000;
const BETWEEN_CLIPS_COOLDOWN_MS = 8 * 60 * 1000;
const BETWEEN_JOBS_COOLDOWN_MS = 30 * 60 * 1000;
let loopBusy = false;
let lastLoggedStatusKey = '';
const activeWatches = new Set();

async function emitLog(level, stage, message, details = {}) {
  try {
    const { backendUrl, currentJob } = await state();
    await fetch(`${backendUrl}/api/extension/logs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        level,
        source: 'extension',
        stage,
        message: String(message || ''),
        jobId: details.jobId ?? currentJob?.jobId ?? null,
        clipIndex: details.clipIndex ?? currentJob?.clipIndex ?? null,
        durationMs: details.durationMs,
        error: details.error ? {
          name: details.error.name || 'Error',
          message: details.error.message || String(details.error),
          stack: String(details.error.stack || '').split('\n').slice(0, 10).join('\n'),
        } : undefined,
        meta: details.meta,
      }),
    });
  } catch (_) {
    console[level === 'error' ? 'error' : 'log'](`[ClipBot:${stage}] ${message}`);
  }
}

async function state() {
  const value = await chrome.storage.local.get([
    'backendUrl', 'running', 'creditLocked', 'lastStatus', 'currentJob',
    'nextJobCooldownUntil', 'durationSeconds',
  ]);
  const storedBackend = String(value.backendUrl || '').replace(/\/$/, '');
  const backendUrl = !storedBackend || storedBackend === 'http://127.0.0.1:8100'
    ? DEFAULT_API
    : storedBackend;
  return {
    backendUrl,
    running: Boolean(value.running),
    creditLocked: value.creditLocked !== false,
    lastStatus: value.lastStatus || 'บอทหยุดอยู่',
    currentJob: value.currentJob || null,
    nextJobCooldownUntil: Number(value.nextJobCooldownUntil || 0),
    durationSeconds: Number(value.durationSeconds) === 16 ? 16 : 24,
  };
}

async function api(path, options = {}) {
  const { backendUrl } = await state();
  const started = Date.now();
  try {
    const response = await fetch(`${backendUrl}${path}`, options);
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Web App ตอบกลับ ${response.status}`);
    return data;
  } catch (error) {
    emitLog('error', 'api.request', `${options.method || 'GET'} ${path} ล้มเหลว`, {
      durationMs: Date.now() - started,
      error,
    });
    throw error;
  }
}

async function ensureQueuedJob(itemId, durationSeconds = 24) {
  return api('/api/extension/jobs/auto', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      itemId: Number(itemId) > 0 ? Number(itemId) : null,
      durationSeconds: Number(durationSeconds) === 16 ? 16 : 24,
    }),
  });
}

function debuggerCall(method, ...args) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeout = setTimeout(() => {
      settled = true;
      reject(new Error(`Chrome debugger ${method} timed out`));
    }, 10000);
    chrome.debugger[method](...args, (result) => {
      const error = chrome.runtime.lastError;
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      if (error) reject(new Error(error.message));
      else resolve(result);
    });
  });
}

async function typePromptLikeKeyboard(tabId, prompt) {
  const target = { tabId };
  await debuggerCall('attach', target, '1.3');
  try {
    const key = (params) => debuggerCall('sendCommand', target, 'Input.dispatchKeyEvent', params);
    await key({ type: 'keyDown', key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65, modifiers: 2 });
    await key({ type: 'keyUp', key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65, modifiers: 2 });
    await key({ type: 'keyDown', key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8 });
    await key({ type: 'keyUp', key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8 });
    for (const character of prompt) {
      await debuggerCall('sendCommand', target, 'Input.insertText', { text: character });
      await new Promise((resolve) => setTimeout(resolve, 8 + Math.floor(Math.random() * 9)));
    }
    return { ok: true };
  } finally {
    await debuggerCall('detach', target).catch(() => {});
  }
}

async function clickLikeMouse(tabId, x, y) {
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x > 10000 || y > 10000) {
    throw new Error('Invalid click coordinates');
  }
  const target = { tabId };
  await debuggerCall('attach', target, '1.3');
  try {
    await debuggerCall('sendCommand', target, 'Input.dispatchMouseEvent', {
      type: 'mouseMoved', x, y,
    });
    await debuggerCall('sendCommand', target, 'Input.dispatchMouseEvent', {
      type: 'mousePressed', x, y, button: 'left', buttons: 1, clickCount: 1,
    });
    await new Promise((resolve) => setTimeout(resolve, 60));
    await debuggerCall('sendCommand', target, 'Input.dispatchMouseEvent', {
      type: 'mouseReleased', x, y, button: 'left', buttons: 0, clickCount: 1,
    });
    return { ok: true };
  } finally {
    await debuggerCall('detach', target).catch(() => {});
  }
}

async function waitForChromeDownload(downloadId, timeoutMs = 120000) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.downloads.onChanged.removeListener(onChanged);
      reject(new Error('Chrome ดาวน์โหลดคลิปไม่เสร็จภายใน 2 นาที'));
    }, timeoutMs);

    async function finish() {
      const [item] = await chrome.downloads.search({ id: downloadId });
      if (!item) throw new Error('ไม่พบรายการดาวน์โหลดของ Chrome');
      if (item.state === 'interrupted') throw new Error(`Chrome ดาวน์โหลดไม่สำเร็จ: ${item.error || 'interrupted'}`);
      if (item.state !== 'complete') return;
      clearTimeout(timeout);
      chrome.downloads.onChanged.removeListener(onChanged);
      resolve(item);
    }

    function onChanged(delta) {
      if (delta.id !== downloadId || (!delta.state && !delta.error)) return;
      finish().catch((error) => {
        clearTimeout(timeout);
        chrome.downloads.onChanged.removeListener(onChanged);
        reject(error);
      });
    }

    chrome.downloads.onChanged.addListener(onChanged);
    finish().catch((error) => {
      clearTimeout(timeout);
      chrome.downloads.onChanged.removeListener(onChanged);
      reject(error);
    });
  });
}

async function downloadAndImportClip(videoUrl, apiBase, jobId, clipIndex) {
  const started = Date.now();
  await emitLog('info', 'clip.download', 'เริ่มดาวน์โหลดคลิปจาก Flow', { jobId, clipIndex });
  const filename = `ClipBot/clipbot_job_${jobId}_clip_${clipIndex + 1}.mp4`;
  const downloadId = await chrome.downloads.download({
    url: videoUrl,
    filename,
    conflictAction: 'overwrite',
    saveAs: false,
  });
  try {
    const item = await waitForChromeDownload(downloadId);
    const bytes = Math.max(0, Number(item.fileSize || 0), Number(item.totalBytes || 0), Number(item.bytesReceived || 0));
    if (!item.filename || bytes < 1024) {
      throw new Error('Chrome ดาวน์โหลดคลิปได้ไฟล์ว่างหรือไม่พบ path');
    }
    if (/^image\//i.test(String(item.mime || ''))) {
      throw new Error(`Flow ส่ง thumbnail รูปภาพแทนวิดีโอ (${item.mime}) — ไม่บันทึกเป็นคลิป`);
    }

    const response = await fetch(`${apiBase}/api/extension/jobs/${jobId}/downloads/${clipIndex}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ downloadPath: item.filename, sourceUrl: videoUrl }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Local Service นำเข้าคลิปไม่สำเร็จ (${response.status})`);
    await emitLog('info', 'clip.download', 'ดาวน์โหลดและนำเข้าคลิปสำเร็จ', {
      jobId,
      clipIndex,
      durationMs: Date.now() - started,
      meta: { bytes },
    });
    return { data, size: bytes, downloadId };
  } finally {
    // Failed thumbnail/HTML downloads must not remain and collide with a later
    // retry under the same deterministic filename.
    await chrome.downloads.removeFile(downloadId).catch(() => {});
    await chrome.downloads.erase({ id: downloadId }).catch(() => {});
  }
}

async function downloadAndImportGeneratedImage(imageUrl, apiBase, jobId) {
  const started = Date.now();
  await emitLog('info', 'image.download', 'Downloading generated product image from Flow', { jobId });
  const downloadId = await chrome.downloads.download({
    url: imageUrl,
    filename: `ClipBot/clipbot_job_${jobId}_generated_start.png`,
    conflictAction: 'overwrite',
    saveAs: false,
  });
  try {
    const item = await waitForChromeDownload(downloadId);
    const bytes = Math.max(0, Number(item.fileSize || 0), Number(item.totalBytes || 0), Number(item.bytesReceived || 0));
    if (!item.filename || bytes < 2048) throw new Error('Flow returned an empty generated image');
    if (item.mime && !/^image\//i.test(String(item.mime))) {
      throw new Error(`Flow returned a non-image payload (${item.mime})`);
    }
    const response = await fetch(`${apiBase}/api/extension/jobs/${jobId}/generated-image`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ downloadPath: item.filename, sourceUrl: imageUrl }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Local Service could not import the generated image (${response.status})`);
    await emitLog('info', 'image.download', 'Generated product image imported', {
      jobId,
      durationMs: Date.now() - started,
      meta: { bytes },
    });
    return { data, size: bytes, downloadId };
  } finally {
    await chrome.downloads.removeFile(downloadId).catch(() => {});
    await chrome.downloads.erase({ id: downloadId }).catch(() => {});
  }
}

async function setStatus(message, patch = {}) {
  await chrome.storage.local.set({ lastStatus: message, ...patch });
  const current = await state();
  const statusKey = `${message}|${current.currentJob?.jobId || ''}|${current.currentJob?.clipIndex ?? ''}|${current.running}`;
  if (statusKey !== lastLoggedStatusKey) {
    lastLoggedStatusKey = statusKey;
    emitLog('info', 'bot.status', message, {
      jobId: current.currentJob?.jobId,
      clipIndex: current.currentJob?.clipIndex,
      meta: { running: current.running, creditLocked: current.creditLocked },
    });
  }
  try {
    const reply = await api('/api/extension/status', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        running: current.running,
        creditLocked: current.creditLocked,
        status: message,
        currentJobId: current.currentJob?.jobId || null,
        // ส่งเวอร์ชันมาด้วย จะได้รู้แน่ๆ ว่า Chrome โหลดโค้ดตัวไหนอยู่
        // (เคยเสียเวลาไล่บั๊กที่แก้ไปแล้ว เพราะ reload ไม่ติดโดยไม่มีใครรู้)
        version: chrome.runtime.getManifest().version,
      }),
    });
    // service ส่งคำสั่งรีโมตกลับมาได้ (ใช้ตอน debug — ปกติคุมจากป๊อปอัป)
    // ใช้ commandPayload ก่อน (มีพารามิเตอร์) แล้วค่อย fallback เป็น command แบบ string
    if (reply?.commandPayload || reply?.command) {
      await handleRemoteCommand(reply.commandPayload || reply.command);
    }
  } catch (_) { /* heartbeat จะลองใหม่ */ }
}

/**
 * รับคำสั่งจาก Local Service (one-shot — service ลบคำสั่งทิ้งหลังส่งแล้ว)
 *
 * มีไว้เพื่อให้ไล่บั๊กได้โดยไม่ต้องให้คนกด Start ซ้ำเป็นสิบรอบ
 * ยังเคารพ credit lock อยู่ — ปลดล็อกเองไม่ได้ ต้องคนปลดเท่านั้น
 */
async function handleRemoteCommand(payload) {
  // รองรับทั้งแบบส่งชื่อคำสั่งเฉยๆ และแบบส่งทั้งก้อนพร้อมพารามิเตอร์
  const command = typeof payload === 'string' ? payload : payload?.command;
  const current = await state();

  // ── กู้คลิปที่ Veo เจนเสร็จแล้วแต่บอทเก็บไม่ทัน ──
  //
  // URL ของคลิปต้องใช้ cookie ของ labs.google ถึงจะโหลดได้
  // ฝั่ง Node โหลดเองไม่ได้ → ต้องให้ background ของ extension เป็นคนโหลด
  // (มี host_permissions + credentials:'include' อยู่แล้ว)
  // ใช้ตอนจ่าย credit ไปแล้วแต่คลิปหลุดมือ จะได้ไม่ต้องเจนซ้ำ
  if (command === 'salvage') {
    try {
      await chrome.storage.local.set({ lastStatus: 'กำลังกู้คลิปที่เจนไว้แล้ว...' });
      const outcome = await downloadAndImportClip(
        payload.url, current.backendUrl, payload.jobId, payload.clipIndex
      );
      await chrome.storage.local.set({
        lastStatus: `กู้คลิป ${payload.clipIndex + 1} สำเร็จ (${Math.round(outcome.size / 1024)} KB)`,
      });
    } catch (error) {
      await chrome.storage.local.set({ lastStatus: `กู้คลิปไม่สำเร็จ: ${error.message}` });
    }
    return;
  }

  // โหลดโค้ดใหม่จากดิสก์เอง — ทำให้ไม่ต้องให้คนไปกด Reload ที่ chrome://extensions อีก
  // (extension แบบ unpacked เรียก chrome.runtime.reload() แล้วอ่านไฟล์ใหม่ให้เลย)
  if (command === 'reload') {
    await chrome.storage.local.set({ lastStatus: 'รีโมตสั่งโหลดโค้ดใหม่...', running: false, currentJob: null, submittedFor: null });
    chrome.runtime.reload();
    return;
  }

  // ปลด/ล็อกเครดิตจากรีโมต — เจ้าของเครื่องอนุญาตให้สั่งได้เมื่อ 17 ก.ค. 2026
  // (จำเป็นด้วย เพราะทุกครั้งที่ reload ตัว onInstalled จะล็อกเครดิตกลับอัตโนมัติ)
  if (command === 'unlock' || command === 'lock') {
    const locked = command === 'lock';
    await chrome.storage.local.set({
      creditLocked: locked,
      lastStatus: locked ? 'รีโมตล็อกเครดิตแล้ว' : 'รีโมตปลดล็อกเครดิตแล้ว — พร้อมเริ่ม',
      running: locked ? false : current.running,
    });
    return;
  }

  // สั่งถ่าย DOM ของแท็บ Flow ตอนนี้เลย — ใช้ส่องตอนบอทค้างโดยไม่มี error
  // (ไม่แตะอะไรบนหน้า ไม่เสีย credit)
  if (command === 'snapshot') {
    try {
      const tab = await flowTab();
      await chrome.tabs.sendMessage(tab.id, { type: 'FLOW_SNAPSHOT' }).catch(async () => {
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
        await chrome.tabs.sendMessage(tab.id, { type: 'FLOW_SNAPSHOT' });
      });
      await chrome.storage.local.set({ lastStatus: 'ถ่าย DOM ตามคำสั่งรีโมตแล้ว' });
    } catch (error) {
      await chrome.storage.local.set({ lastStatus: `ถ่าย DOM ไม่สำเร็จ: ${error.message}` });
    }
    return;
  }

  if (command === 'start') {
    if (current.creditLocked) {
      await chrome.storage.local.set({ lastStatus: 'รีโมตสั่ง Start แต่เครดิตล็อกอยู่ — ปลดล็อกก่อน' });
      return;
    }
    if (current.running) return;
    const queued = await ensureQueuedJob(null, current.durationSeconds);
    await chrome.storage.local.set({
      lastStatus: queued.random ? `สุ่มสินค้าอัตโนมัติแล้ว — งาน #${queued.id}` : `เริ่มงานที่รออยู่ #${queued.id}`,
      running: true,
      currentJob: null,
      submittedFor: null,
    });
    runNext();
  } else if (command === 'stop') {
    await chrome.storage.local.set({ lastStatus: 'รีโมตสั่งหยุดบอท', running: false, currentJob: null, submittedFor: null });
  }
}

async function flowTab() {
  const tabs = await chrome.tabs.query({ url: 'https://labs.google/*' });
  const flowTabs = tabs.filter((tab) => /\/tools\/flow|\/flow\/project/.test(tab.url || ''));
  const usable = flowTabs.find((tab) => tab.active)
    || flowTabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
  if (usable?.id) return usable;
  return chrome.tabs.create({ url: 'https://labs.google/fx/th/tools/flow', active: true });
}

function imageUrl(apiBase, imagePath) {
  return `${apiBase}/api/media?path=${encodeURIComponent(imagePath)}`;
}

async function sendCurrentJob(tabId) {
  const current = await state();
  if (!current.running || !current.currentJob) return;
  if (current.currentJob.phase === 'cooldown') {
    if (Number(current.currentJob.cooldownUntil || 0) > Date.now()) return;
    await chrome.storage.local.set({
      currentJob: { ...current.currentJob, phase: 'preparing', cooldownUntil: null },
    });
    await chrome.storage.local.remove('submittedFor');
  }

  // ── กันส่งงานซ้ำเด็ดขาด ──
  //
  // chrome.tabs.onUpdated ยิงทุกครั้งที่หน้าโหลดเสร็จ และ Flow เปลี่ยนหน้าเองหลังกด Generate
  // → content script ถูกฉีดใหม่ (working flag รีเซ็ต) → รันทับตัวที่กำลังรอวิดีโออยู่
  // → ตัวใหม่พังบนหน้าที่โหลดไม่เสร็จ → job โดนมาร์ค failed + currentJob ถูกล้าง
  // → พอตัวเดิมเจอวิดีโอ ส่งกลับมาก็ถูกปฏิเสธ = "จ่าย credit แล้วแต่คลิปหาย"
  //
  // เก็บใน storage ไม่ใช่ตัวแปร เพราะ service worker ของ MV3 ถูกฆ่าได้ตลอด
  // Fail closed when an old/stale Web App returns a job without the stage.
  // Defaulting an unknown stage to video skips the paid reference-image step
  // and can spend credits on the wrong workflow.
  if (!['image', 'video'].includes(current.currentJob.stage)) {
    throw new Error('Web App ส่งขั้นตอนงานไม่ครบ (ไม่มี image/video stage) — กรุณารีสตาร์ต Web App');
  }
  const stage = current.currentJob.stage;
  const key = `${current.currentJob.jobId}:${stage}:${current.currentJob.clipIndex}`;
  const saved = await chrome.storage.local.get('submittedFor');
  if (saved.submittedFor === key) {
    console.log('[ClipBot] ข้ามการส่งซ้ำสำหรับ', key);
    return;
  }
  await chrome.storage.local.set({ submittedFor: key });

  const message = {
    type: stage === 'image' ? 'FLOW_RUN_IMAGE' : 'FLOW_RUN_CLIP',
    stage,
    jobId: current.currentJob.jobId,
    clipIndex: current.currentJob.clipIndex,
    projectReady: current.currentJob.projectReady === true,
    imageUrl: imageUrl(current.backendUrl, current.currentJob.imagePath),
    prompt: current.currentJob.prompt,
    clipCount: Number(current.currentJob.clipCount || 3),
    targetDurationSeconds: Number(current.currentJob.targetDurationSeconds || 24),
  };
  try {
    await chrome.tabs.sendMessage(tabId, message);
  } catch (error) {
    const detail = String(error?.message || error);
    if (!/Receiving end does not exist|Could not establish connection/i.test(detail)) throw error;
    await setStatus('กำลังติดตั้งตัวบอทลงในแท็บ Flow ที่เปิดค้างอยู่');
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    await chrome.tabs.sendMessage(tabId, message);
  }
}

async function runNext() {
  if (loopBusy) return;
  loopBusy = true;
  try {
    const current = await state();
    if (!current.running || current.creditLocked) return;

    // ห้าม return เงียบๆ ตรงนี้เด็ดขาด — ถ้ามีงานค้างต้องบอกให้เห็นบนหน้าจอ
    // ไม่งั้นอาการจะออกมาเป็น "กด Start แล้วบอทนิ่งสนิท ไม่มี error ไม่มีอะไรเลย"
    // ซึ่งหาสาเหตุแทบไม่ได้ถ้าไม่ไปไล่อ่าน chrome.storage
    if (current.currentJob) {
      await setStatus(
        `มีงาน #${current.currentJob.jobId} ค้างอยู่ — กดหยุด หรือ reload Extension เพื่อล้างก่อนเริ่มใหม่`
      );
      return;
    }

    await setStatus(`Gemini กำลังเลือกภาพและวางแผน ${current.durationSeconds === 16 ? 2 : 3} คลิป`);
    const result = await api('/api/extension/jobs/claim', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ creditUnlocked: true }),
    });
    if (!result.job) {
      await setStatus('คิวว่าง — รองานใหม่');
      return;
    }
    if (!['image', 'video'].includes(result.job.stage)) {
      throw new Error('Web App เวอร์ชันเก่าส่งงานโดยไม่มี stage — หยุดก่อนเพื่อไม่ให้ข้ามการสร้างรูป');
    }
    await setStatus(`กำลังเปิด Flow สำหรับงาน #${result.job.jobId}`, { currentJob: result.job });
    const tab = await flowTab();
    if (!tab.id) throw new Error('เปิดแท็บ Flow ไม่สำเร็จ');
    if (tab.status === 'complete') await sendCurrentJob(tab.id);
  } catch (error) {
    console.error('[ClipBot] runNext failed', error);
    // ถ้าจองงานไปแล้วค่อยพัง ต้องปล่อยงานคืนด้วย (failCurrent เคลียร์ currentJob ให้)
    //
    // ห้ามแค่ setStatus({running:false}) เฉยๆ เพราะ currentJob จะค้างใน storage
    // แล้วรอบหน้า runNext จะ return ทันทีที่บรรทัด `if (... || current.currentJob)`
    // → กด Start แล้ว "ไม่มีอะไรเกิดขึ้น" แบบหาสาเหตุไม่เจอ ต้องล้าง storage เองถึงหาย
    const stuck = await state();
    if (stuck.currentJob) {
      await failCurrent(error.message);
    } else {
      await setStatus(`หยุดเพื่อความปลอดภัย: ${error.message}`, { running: false });
    }
  } finally {
    loopBusy = false;
  }
}

/**
 * รอวิดีโอใหม่จากฝั่ง background — ห้ามให้ content script เป็นคนรอ
 *
 * เหตุผล: Flow re-render หน้าตอนเจนเสร็จ → content script ถูกทำลาย → คลิปหาย
 * background poll ผ่าน chrome.scripting.executeScript แทน ซึ่งอยู่รอดข้ามการ re-render
 * (ถ้า service worker ถูกฆ่า heartbeat จะปลุกกลับมา แล้ว watchForClip ถูกเรียกใหม่จาก storage)
 */
function mediaKey(url) {
  try {
    const parsed = new URL(url);
    return parsed.searchParams.get('name') || parsed.href;
  } catch (_) {
    return String(url || '');
  }
}

function watchKey(jobId, clipIndex, mediaType = 'video') {
  return `${jobId}:${mediaType}:${clipIndex}`;
}

function startClipWatch(tabId, jobId, clipIndex, before, deadlineAt, mediaType = 'video') {
  const key = watchKey(jobId, clipIndex, mediaType);
  if (activeWatches.has(key)) return false;
  activeWatches.add(key);
  watchForClip(tabId, jobId, clipIndex, before, deadlineAt, mediaType)
    .catch(async (error) => {
      const live = await state();
      if (live.currentJob?.jobId === jobId && live.currentJob?.clipIndex === clipIndex) {
        await failCurrent(error.message);
      }
    })
    .catch((error) => console.error('[ClipBot] watch recovery failed', error))
    .finally(() => activeWatches.delete(key));
  return true;
}

async function resumeCurrentWatch(current) {
  const job = current.currentJob;
  if (!current.running || !job || !['awaitingVideo', 'awaitingImage'].includes(job.phase)) return false;
  const tabs = await chrome.tabs.query({ url: 'https://labs.google/*' });
  const tab = tabs.find((candidate) => candidate.active && /\/tools\/flow|\/flow\/project/.test(candidate.url || ''))
    || tabs.find((candidate) => /\/tools\/flow|\/flow\/project/.test(candidate.url || ''));
  if (!tab?.id) {
    await failCurrent('แท็บ Google Flow ถูกปิดระหว่างรอผล — หยุดเพื่อไม่ให้สร้างซ้ำ');
    return false;
  }
  return startClipWatch(
    tab.id,
    job.jobId,
    job.clipIndex,
    Array.isArray(job.watchBefore) ? job.watchBefore : [],
    Number(job.watchDeadline || 0),
    job.phase === 'awaitingImage' ? 'image' : 'video'
  );
}

async function watchForClip(tabId, jobId, clipIndex, before, deadlineAt = 0, mediaType = 'video') {
  const current = await state();
  const known = new Set([
    ...(before || []),
    ...(current.currentJob?.clipUrls || []),
  ].map(mediaKey).filter(Boolean));
  // The deadline is persisted before Generate is clicked. Recreating an MV3
  // service worker must not silently grant another 15-minute wait window.
  const storedDeadline = Number(deadlineAt || current.currentJob?.watchDeadline || 0);
  const deadline = Number.isFinite(storedDeadline) && storedDeadline > 0
    ? storedDeadline
    : Date.now() + FLOW_VIDEO_TIMEOUT_MS;
  let crashReloads = 0;
  // Persist this on the job: Chrome may suspend/restart the MV3 service worker
  // while Flow is generating. A local-only counter would reset and could retry
  // indefinitely across worker restarts.
  let failedCardRetries = Number(current.currentJob?.failedCardRetries || 0);
  const watchStartedAt = Number(current.currentJob?.watchStartedAt || Date.now());
  const acceptMediaAfter = mediaType === 'image' ? watchStartedAt + 12000 : 0;
  // Flow can briefly render a failed placeholder while the image request is
  // still finishing on the server. Job #32 proved that a valid generated image
  // may appear after that placeholder. Give image generation time to settle;
  // fresh media always wins over the transient failure card.
  const failedCardGraceUntil = watchStartedAt + 120000;
  let transientFailureLogged = false;

  while (Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 4000));

    // ผู้ใช้อาจกดหยุด/ล็อกระหว่างรอ ต้องหยุดตัวเฝ้าทันที
    const live = await state();
    if (!live.running || live.currentJob?.jobId !== jobId) return;

    let found = null;
    try {
      const [result] = await chrome.scripting.executeScript({
        target: { tabId },
        func: (allowFailedCardRetry, knownKeys, failedBefore, expectedMediaType) => {
          const candidates = new Map();
          // Never accept IMG thumbnails as finished clips. Flow renders the
          // thumbnail before the video element; accepting it early previously
          // downloaded a .jpg under an .mp4 job and lost the paid result.
          const nodes = document.querySelectorAll(
            expectedMediaType === 'image' ? 'img[src*="getMediaUrlRedirect"]' : 'video,source'
          );
          for (const node of nodes) {
            const raw = node.currentSrc || node.getAttribute('src') || '';
            if (!raw) continue;
            let url;
            try { url = new URL(raw, location.href).href; } catch (_) { continue; }
            const card = node.closest('a,button,[role="button"]') || node.parentElement;
            const label = [
              card?.textContent,
              card?.getAttribute?.('aria-label'),
              node.getAttribute?.('aria-label'),
              node.getAttribute?.('alt'),
            ].filter(Boolean).join(' ');
            const isVideo = /^(VIDEO|SOURCE)$/.test(node.tagName)
              || Boolean(card?.querySelector?.('video,source'))
              || /play_circle|videocam|video|วิดีโอ/i.test(label);
            if (expectedMediaType === 'video' && !isVideo) continue;
            if (expectedMediaType === 'image') {
              if (node.tagName !== 'IMG') continue;
              if (node.naturalWidth && node.naturalWidth < 128) continue;
              if (node.naturalHeight && node.naturalHeight < 128) continue;
            }
            let key = url;
            try { key = new URL(url).searchParams.get('name') || url; } catch (_) {}
            const priority = /^(VIDEO|SOURCE)$/.test(node.tagName)
              ? 3
              : /mediaUrlType=MEDIA_URL_TYPE_THUMBNAIL/i.test(url)
                ? 1
                : 2;
            const previous = candidates.get(key);
            const generated = expectedMediaType === 'image'
              && /รูปภาพที่สร้างขึ้น|generated image|image generated/i.test(label);
            if (!previous || priority > previous.priority || generated) {
              candidates.set(key, { key, url, priority, generated });
            }
          }
          // Flow shows a failed-generation card with three actions:
          // refresh/try again, reuse prompt, delete. Only click the explicit
          // "try again" child button; never the enclosing card or other refresh controls.
          const knownMedia = new Set(knownKeys || []);
          const pendingGeneration = [...document.querySelectorAll('[role="button"]')]
            .filter((element) => element.getClientRects().length > 0)
            .some((element) => {
              const label = [element.textContent, element.getAttribute('aria-label'), element.getAttribute('title')]
                .filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
              return /(?:อยู่ในคิว|queued|กำลังสร้าง|generating|processing)/i.test(label)
                && label.length < 1200;
            });
          const hasFreshExpectedMedia = [...candidates.values()].some((candidate) =>
            !knownMedia.has(candidate.key)
            && (expectedMediaType !== 'image' || candidate.generated)
          );
          const failedCards = [...document.querySelectorAll('[role="button"]')]
            .filter((element) => element.getClientRects().length > 0)
            .filter((element) => {
              const label = [element.textContent, element.getAttribute('aria-label'), element.getAttribute('title')]
                .filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
              return /(?:warning.*(?:ล้มเหลว|failed)|(?:ล้มเหลว|failed).*warning)/i.test(label)
                && label.length < 600;
            });
          // Ignore failure cards that were already on the page before this
          // generation. Pick the newest card only, and never retry after a new
          // video is already available.
          const hasNewFailedCard = failedCards.length > Number(failedBefore || 0);
          const failedCard = hasNewFailedCard ? failedCards[failedCards.length - 1] : null;
          // Only a newly-created failed card may block the active request.
          // Old failure cards remain in Flow projects and must not poison a
          // later generation merely because their text is still on the page.
          const failedCardText = failedCard
            ? [failedCard.textContent, failedCard.getAttribute('aria-label'), failedCard.getAttribute('title')]
              .filter(Boolean).join(' ').replace(/\s+/g, ' ').trim()
            : '';
          const unusualActivity = Boolean(failedCard) &&
            /(?:กิจกรรมที่ผิดปกติ|กิจกรรมผิดปกติ|unusual activity|suspicious activity|abnormal activity)/i.test(failedCardText);
          let retryButton = null;
          if (failedCard && !hasFreshExpectedMedia) {
            const cardRect = failedCard.getBoundingClientRect();
            // Flow sometimes portals the three action controls outside the
            // failed-card DOM subtree. Use visual containment as well as DOM
            // containment so the icon-only refresh control is still found.
            const actions = [...document.querySelectorAll('button,[role="button"]')]
              .filter((element) => {
                if (element === failedCard || element.getClientRects().length === 0) return false;
                const rect = element.getBoundingClientRect();
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;
                return failedCard.contains(element)
                  || (centerX >= cardRect.left && centerX <= cardRect.right
                    && centerY >= cardRect.top && centerY <= cardRect.bottom);
              })
              .map((element) => ({
                element,
                label: [element.textContent, element.getAttribute('aria-label'), element.getAttribute('title')]
                  .filter(Boolean).join(' ').replace(/\s+/g, ' ').trim(),
              }));
            retryButton = actions.find(({ label }) =>
              /(?:refresh|restart_alt|ลองอีกครั้ง|ลองใหม่|Try again|Retry)/i.test(label)
            )?.element || null;
            if (!retryButton) {
              const unlabeled = actions.filter(({ label }) => !label);
              if (unlabeled.length === 1) retryButton = unlabeled[0].element;
            }
          }
          let retryPoint = null;
          if (retryButton && allowFailedCardRetry && !unusualActivity) {
            const rect = retryButton.getBoundingClientRect();
            retryPoint = {
              x: rect.left + rect.width / 2,
              y: rect.top + rect.height / 2,
            };
          }
          return {
            candidates: [...candidates.values()],
            failedCard: Boolean(failedCard),
            pendingGeneration,
            retryPoint,
            retriedFailedCard: false,
            unusualActivity,
            crashed: /Application error:\s*a client-side exception has occurred|client-side exception has occurred while loading labs\.google/i
              .test(document.body?.innerText || ''),
            alert: [...document.querySelectorAll('[role="alert"]')]
              .map((a) => (a.textContent || '').trim())
              // Flow always renders a hidden accessibility alert containing the page title.
              // It is not an error and must not abort a paid generation.
              .find((t) => t && !/^Google Flow\s*-/i.test(t)) || null,
          };
        },
        args: [
          false, // Never click a paid-generation Retry automatically.
          [...known].slice(-500),
          Number(current.currentJob?.watchFailedBefore || 0),
          mediaType,
        ],
      });
      const data = result?.result;
      if (data?.crashed) {
        if (crashReloads >= 2) {
          throw new Error('Flow crash ซ้ำหลังรีโหลดอัตโนมัติ 2 ครั้ง — หยุดเพื่อกันการทำงานผิดบัญชีหรือ session หมดอายุ');
        }
        crashReloads += 1;
        await setStatus(`Flow crash ระหว่างรอคลิป — รีโหลดอัตโนมัติครั้งที่ ${crashReloads} (ไม่กดสร้างซ้ำ)`);
        await emitLog('warn', 'flow.crash-recovery', 'พบหน้า Application error และรีโหลดโปรเจกต์เดิม', {
          jobId,
          clipIndex,
          meta: { attempt: crashReloads },
        });
        await chrome.tabs.reload(tabId);
        // submittedFor ยังอยู่ใน chrome.storage ดังนั้น onUpdated จะไม่ส่ง Generate ซ้ำ
        await new Promise((resolve) => setTimeout(resolve, 7000));
        continue;
      }
      if (data?.unusualActivity) {
        throw new Error('Flow ตรวจพบกิจกรรมผิดปกติ — หยุดทันทีและห้ามกดลองอีกครั้ง');
      }
      const freshCandidates = (data?.candidates || [])
        .filter((candidate) => !known.has(candidate.key));
      // An uploaded reference can carry the same generic generated-image alt
      // text as real output. Require both a fresh media id and Flow's generated
      // label, then wait briefly for redirect URLs to settle before download.
      found = Date.now() >= acceptMediaAfter
        ? freshCandidates.find((candidate) => mediaType !== 'image' || candidate.generated)?.url || null
        : null;

      // Never let a stale/transient failure card override media that already
      // appeared. Flow uses the same temporary placeholder before both image
      // and video cards settle into queued/processing state, so wait through it
      // before attempting Retry or declaring the job failed.
      if (!found && data?.failedCard && Date.now() < failedCardGraceUntil) {
        if (!transientFailureLogged) {
          transientFailureLogged = true;
          await setStatus(`งาน #${jobId}: Flow แสดงสถานะล้มเหลวชั่วคราว — รอ${mediaType === 'image' ? 'ภาพ' : 'คลิป'}ใหม่อีกไม่เกิน 2 นาที`);
          await emitLog('warn', 'flow.image-failure-grace', 'พบการ์ดล้มเหลวระหว่างที่ภาพใหม่อาจยังประมวลผลอยู่', {
            jobId,
            clipIndex,
            meta: { graceUntil: failedCardGraceUntil },
          });
        }
        continue;
      }
      if (!found && transientFailureLogged && Date.now() >= failedCardGraceUntil
        && !data?.failedCard && !data?.pendingGeneration) {
        throw new Error(`Flow นำการ์ด${mediaType === 'image' ? 'ภาพ' : 'คลิป'}ออกจากคิวโดยไม่มีไฟล์ผลลัพธ์ — หยุดเพื่อกันเครดิตซ้ำ`);
      }
      // A stale failed card can remain beside a newer generation card. As long
      // as Flow explicitly reports queued/generating/processing, keep watching
      // and never Retry or fail the active paid request.
      if (!found && data?.pendingGeneration) continue;
      if (found) {
        // Skip Retry/failure handling below. The generated media is the
        // authoritative outcome even if Flow left a failed placeholder behind.
      } else if (data?.retryPoint && failedCardRetries < 2) {
        await clickLikeMouse(tabId, Number(data.retryPoint.x), Number(data.retryPoint.y));
        data.retriedFailedCard = true;
      }
      if (data?.retriedFailedCard) {
        failedCardRetries += 1;
        const latest = await state();
        await setStatus(`Flow สร้างคลิปไม่สำเร็จ — กด "ลองอีกครั้ง" อัตโนมัติ (${failedCardRetries}/2)`, {
          currentJob: latest.currentJob?.jobId === jobId
            ? { ...latest.currentJob, failedCardRetries }
            : latest.currentJob,
        });
        await emitLog('warn', 'flow.generation-retry', 'กดปุ่มลองอีกครั้งบนการ์ดสร้างคลิปล้มเหลว', {
          jobId,
          clipIndex,
          meta: { attempt: failedCardRetries },
        });
        await new Promise((resolve) => setTimeout(resolve, 5000));
        continue;
      }
      if (!found && data?.failedCard) {
        throw new Error(failedCardRetries >= 2
          ? 'Flow สร้างสื่อล้มเหลวซ้ำหลังจากกด "ลองอีกครั้ง" 2 ครั้ง — หยุดเพื่อป้องกันการวนซ้ำ'
          : 'Flow สร้างสื่อล้มเหลวและไม่พบปุ่มลองอีกครั้งที่กดได้ — หยุดเพื่อป้องกันการกดผิดปุ่ม');
      }
      if (!found && data?.alert) throw new Error(`Flow แจ้ง: ${data.alert}`);
    } catch (error) {
      // แท็บกำลังโหลด/นำทางอยู่ — ลองใหม่รอบหน้า
      if (/Cannot access|No tab|Frame|closed/i.test(String(error?.message))) continue;
      throw error;
    }

    if (found) {
      const elapsed = Math.round((FLOW_VIDEO_TIMEOUT_MS - (deadline - Date.now())) / 1000);
      await setStatus(mediaType === 'image'
        ? `เจอรูปภาพที่สร้างใหม่ใน ${elapsed}s — กำลังบันทึก`
        : `เจอวิดีโอใหม่ใน ${elapsed}s — กำลังบันทึก`);
      if (mediaType === 'image') {
        await acceptGeneratedImage({ jobId, imageUrl: found, tabId });
      } else {
        await acceptClip({ jobId, clipIndex, videoUrl: found, tabId });
      }
      return;
    }
  }
  throw new Error(`ส่งสร้างแล้วแต่ไม่พบ${mediaType === 'image' ? 'รูปภาพ' : 'วิดีโอ'}ใหม่ภายใน 15 นาที — หยุดเพื่อกันเครดิตซ้ำ`);
}

async function acceptGeneratedImage(message) {
  const current = await state();
  if (!current.currentJob || current.currentJob.jobId !== message.jobId) return;
  await setStatus(`Job #${message.jobId}: saving generated hand-held product image`);
  const outcome = await downloadAndImportGeneratedImage(
    message.imageUrl, current.backendUrl, message.jobId
  );
  await chrome.storage.local.remove('submittedFor');
  const pauseMs = AFTER_IMAGE_COOLDOWN_MS;
  const nextJob = {
    ...outcome.data,
    projectReady: true,
    failedCardRetries: 0,
    phase: 'cooldown',
    cooldownUntil: Date.now() + pauseMs,
    watchBefore: null,
    watchStartedAt: null,
    watchDeadline: null,
    watchFailedBefore: null,
  };
  await setStatus(
    `Generated image saved (${Math.round(outcome.size / 1024)} KB) — cooldown before clip 1/${nextJob.clipCount}`,
    { currentJob: nextJob }
  );
  if (message.tabId) {
    setTimeout(() => sendCurrentJob(message.tabId).catch((error) => failCurrent(error.message)), pauseMs + 50);
  }
}

async function acceptClip(message) {
  const current = await state();
  if (!current.currentJob || current.currentJob.jobId !== message.jobId) return;
  const clipCount = Number(current.currentJob.clipCount || 3);
  await setStatus(`กำลังบันทึกคลิป ${message.clipIndex + 1} จาก ${clipCount}`);

  // ใช้ Chrome Downloads แทน fetch(): ตัวจัดการดาวน์โหลดของ Chrome ตาม redirect
  // และใช้ session cookie ได้โดยไม่ติด CORS แบบ JavaScript fetch
  const outcome = await downloadAndImportClip(
    message.videoUrl, current.backendUrl, message.jobId, message.clipIndex
  );
  await setStatus(`บันทึกคลิป ${message.clipIndex + 1} แล้ว (${Math.round(outcome.size / 1024)} KB)`);
  const result = outcome.data;

  if (result.done) {
    await setStatus(`กำลังประกอบวิดีโองาน #${message.jobId}`);
    await api(`/api/extension/jobs/${message.jobId}/finish`, { method: 'POST' });
    await chrome.storage.local.remove('submittedFor');
    const pauseMs = BETWEEN_JOBS_COOLDOWN_MS;
    const nextJobCooldownUntil = Date.now() + pauseMs;
    await setStatus(`งาน #${message.jobId} เสร็จแล้ว — พักสุ่ม ${Math.round(pauseMs / 60000)} นาที ก่อนงานถัดไป`, {
      currentJob: null,
      nextJobCooldownUntil,
    });
    setTimeout(async () => {
      const live = await state();
      if (live.running && !live.creditLocked && !live.currentJob
        && Number(live.nextJobCooldownUntil || 0) === nextJobCooldownUntil) {
        await chrome.storage.local.remove('nextJobCooldownUntil');
        await runNext();
      }
    }, pauseMs + 50);
    return;
  }

  const pauseMs = BETWEEN_CLIPS_COOLDOWN_MS;
  const nextJob = {
    ...current.currentJob,
    stage: 'video',
    clipIndex: message.clipIndex + 1,
    imagePath: result.imagePath,
    prompt: result.prompt,
    failedCardRetries: 0,
    phase: 'cooldown',
    cooldownUntil: Date.now() + pauseMs,
    watchBefore: null,
    watchStartedAt: null,
    watchDeadline: null,
    watchFailedBefore: null,
  };
  await setStatus(`คลิป ${message.clipIndex + 1} เสร็จ — พักสุ่ม ${Math.round(pauseMs / 60000)} นาที ก่อนเตรียมคลิป ${nextJob.clipIndex + 1} จาก ${clipCount}`, { currentJob: nextJob });
  if (message.tabId) setTimeout(() => sendCurrentJob(message.tabId).catch((error) => failCurrent(error.message)), pauseMs + 50);
}

async function failCurrent(message) {
  const providerBlocked = /กิจกรรมผิดปกติ|unusual activity/i.test(String(message || ''));
  console.error(providerBlocked ? '[ClipBot] job paused by provider' : '[ClipBot] job failed', message);
  const current = await state();
  await emitLog(providerBlocked ? 'warn' : 'error', providerBlocked ? 'job.paused' : 'job.failed', message, {
    jobId: current.currentJob?.jobId,
    clipIndex: current.currentJob?.clipIndex,
  });
  if (current.currentJob?.jobId) {
    try {
      await api(`/api/extension/jobs/${current.currentJob.jobId}/${providerBlocked ? 'pause' : 'fail'}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });
    } catch (_) {}
  }
  await chrome.storage.local.remove('submittedFor');
  // A fatal job failure must restore the human credit gate. Leaving the gate
  // unlocked made the next accidental Start immediately consume more credits.
  const status = providerBlocked
    ? `Flow พักการสร้างชั่วคราว — เก็บรูป/คลิปเดิมไว้แล้ว กรุณารอก่อนเริ่มต่อ: ${message}`
    : `หยุดเพื่อความปลอดภัย: ${message}`;
  await setStatus(status, {
    running: false,
    creditLocked: true,
    currentJob: null,
  });
}

chrome.runtime.onInstalled.addListener(() => {
  // ล้าง currentJob ด้วย! ทำให้ "reload extension" เป็นทางออกฉุกเฉินที่ใช้ได้จริง
  // ถ้าไม่ล้าง งานที่ค้างจะติดอยู่ใน storage ข้ามการ reload
  // แล้วบอทจะนิ่งตลอดกาลจนกว่าจะลบ extension ทิ้งทั้งตัว
  chrome.storage.local.set({
    backendUrl: DEFAULT_API,
    running: false,
    creditLocked: true,
    currentJob: null,
    submittedFor: null,
  });
  chrome.alarms.create('clipbot-heartbeat', { periodInMinutes: 0.25 });
  // Existing pages keep the old content script after an unpacked-extension
  // reload. Refresh Flow once so the new background and content scripts always
  // run the same version; otherwise messages can hang on removed handlers.
  chrome.tabs.query({ url: ['https://labs.google/*'] }, (tabs) => {
    for (const tab of tabs) {
      if (tab.id) chrome.tabs.reload(tab.id).catch(() => {});
    }
  });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('clipbot-heartbeat', { periodInMinutes: 0.25 });
  // Chrome เพิ่งเปิดใหม่ = ไม่มีงานไหนกำลังทำอยู่จริง งานที่ค้างคือขยะจากรอบก่อน
  chrome.storage.local.set({ running: false, currentJob: null, submittedFor: null });
  setStatus('บอทพร้อมใช้งาน — เปิด Extension เพื่อเริ่ม').catch(() => {});
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'clipbot-heartbeat') return;
  const current = await state();
  await setStatus(current.lastStatus);
  // setStatus can consume a remote lock/stop/reload command. Re-read storage;
  // using the stale pre-command state could restart work after it was stopped.
  const live = await state();
  if (live.running && live.currentJob?.phase === 'cooldown') {
    if (Number(live.currentJob.cooldownUntil || 0) <= Date.now()) {
      const tabs = await chrome.tabs.query({ url: 'https://labs.google/*' });
      const tab = tabs.find((candidate) => /\/tools\/flow|\/flow\/project/.test(candidate.url || ''));
      if (tab?.id) {
        await chrome.storage.local.set({
          currentJob: { ...live.currentJob, phase: 'preparing', cooldownUntil: null },
        });
        await chrome.storage.local.remove('submittedFor');
        await sendCurrentJob(tab.id);
      }
    }
  } else if (live.running && ['awaitingVideo', 'awaitingImage'].includes(live.currentJob?.phase)) {
    await resumeCurrentWatch(live);
  } else if (live.running && !live.currentJob) {
    const cooldownUntil = Number(live.nextJobCooldownUntil || 0);
    if (cooldownUntil > Date.now()) return;
    await chrome.storage.local.remove('nextJobCooldownUntil');
    runNext();
  }
});

chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'complete' && /labs\.google\/.*(?:tools\/flow|flow\/project)/.test(tab.url || '')) {
    sendCurrentJob(tabId).catch((error) => failCurrent(error.message));
  }
});

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  (async () => {
    if (message.type === 'GET_STATUS') return { ...(await state()) };
    if (message.type === 'FLOW_RESET_TO_PROJECTS') {
      const current = await state();
      if (current.currentJob?.jobId !== Number(message.jobId)) throw new Error('งานเปลี่ยนระหว่างเตรียมโปรเจกต์');
      await chrome.storage.local.remove('submittedFor');
      await setStatus('กำลังกลับหน้ารวมโปรเจกต์เพื่อสร้างโปรเจกต์ใหม่');
      return { ok: true };
    }
    if (message.type === 'FLOW_CREATING_PROJECT') {
      const current = await state();
      if (current.currentJob?.jobId !== Number(message.jobId)) throw new Error('งานเปลี่ยนระหว่างสร้างโปรเจกต์');
      await chrome.storage.local.remove('submittedFor');
      await setStatus('กดสร้างโปรเจกต์ใหม่แล้ว — รอหน้า editor', {
        currentJob: { ...current.currentJob, projectReady: true },
      });
      return { ok: true };
    }
    if (message.type === 'TYPE_PROMPT') {
      const tabId = sender.tab?.id;
      const tabUrl = String(sender.tab?.url || '');
      const prompt = String(message.prompt || '');
      if (!tabId || !/labs\.google\/.*(?:tools\/flow|flow\/project)/.test(tabUrl)) {
        throw new Error('Typing prompt is allowed only in Google Flow tabs');
      }
      if (!prompt || prompt.length > 4000) throw new Error('Motion Prompt is empty or too long');
      return typePromptLikeKeyboard(tabId, prompt);
    }
    if (message.type === 'TRUSTED_CLICK') {
      const tabId = sender.tab?.id;
      const tabUrl = String(sender.tab?.url || '');
      if (!tabId || !/labs\.google\/.*(?:tools\/flow|flow\/project)/.test(tabUrl)) {
        throw new Error('Native click is allowed only in Google Flow tabs');
      }
      return clickLikeMouse(tabId, Number(message.x), Number(message.y));
    }
    if (message.type === 'FETCH_LOCAL_IMAGE') {
      const current = await state();
      const url = new URL(String(message.url || ''));
      if (url.origin !== new URL(current.backendUrl).origin || url.pathname !== '/api/media') {
        throw new Error('ปฏิเสธ URL รูปที่ไม่ได้มาจาก Local Service');
      }
      const response = await fetch(url.href, { signal: AbortSignal.timeout(30000) });
      if (!response.ok) throw new Error(`Local Service ส่งรูปไม่สำเร็จ (${response.status})`);
      const bytes = new Uint8Array(await response.arrayBuffer());
      let binary = '';
      const chunkSize = 0x8000;
      for (let offset = 0; offset < bytes.length; offset += chunkSize) {
        binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
      }
      await emitLog('info', 'media.fetch', 'โหลดรูปผ่าน Extension background สำเร็จ', {
        jobId: current.currentJob?.jobId,
        clipIndex: current.currentJob?.clipIndex,
        meta: { bytes: bytes.length },
      });
      return { ok: true, base64: btoa(binary), contentType: response.headers.get('content-type') || 'image/jpeg' };
    }
    if (message.type === 'SET_LOCK') {
      const locked = message.locked !== false;
      await setStatus(locked ? 'ล็อกเครดิตแล้ว' : 'ปลดล็อกเครดิตแล้ว — พร้อมเริ่ม', {
        creditLocked: locked, running: locked ? false : (await state()).running,
      });
      return { ok: true };
    }
    if (message.type === 'START') {
      const current = await state();
      if (current.creditLocked) throw new Error('ปลดล็อกเครดิตใน Extension ก่อน');
      const durationSeconds = Number(message.durationSeconds) === 16 ? 16 : 24;
      await chrome.storage.local.set({ durationSeconds });
      const queued = await ensureQueuedJob(message.itemId, durationSeconds);
      const queuedStatus = queued.created
        ? (queued.random ? `สุ่มสินค้าอัตโนมัติแล้ว — งาน #${queued.id}` : `เลือกสินค้าแล้ว — งาน #${queued.id}`)
        : `ใช้งานคิวเดิม — งาน #${queued.id}`;
      await setStatus(queuedStatus, { running: true });
      runNext();
      return { ok: true, ...queued };
    }
    if (message.type === 'STOP') {
      // ต้องปล่อยงานที่จองไว้ด้วย ไม่ใช่แค่เซ็ต running=false
      //
      // ถ้าปล่อย currentJob ค้างไว้ จะติดกับดัก: กด Start ใหม่ runNext() จะ return
      // ทันทีที่ `if (... || current.currentJob)` แบบเงียบสนิท (บอทนิ่งไม่ทำอะไรเลย)
      // และ reload extension ก็ไม่ช่วย เพราะ chrome.storage ไม่ถูกล้าง
      //
      // ฝั่ง DB มาร์คเป็น failed ไว้ก่อน (ไม่ใช่ pending) เพราะถ้าหยุดตอนกำลังเจนค้าง
      // การเอากลับเข้าคิวอัตโนมัติจะทำให้เจนซ้ำ = เสีย credit ฟรี
      // → คลิปที่เจนเสร็จแล้วยังอยู่ใน clip_paths ครบ กู้ต่อได้ด้วย npm run retry-failed
      const current = await state();
      if (current.currentJob?.jobId) {
        try {
          await api(`/api/extension/jobs/${current.currentJob.jobId}/fail`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: 'ผู้ใช้กดหยุดบอท' }),
          });
        } catch (_) { /* ปล่อยงานฝั่ง DB ไม่ได้ก็ต้องล้าง currentJob อยู่ดี */ }
      }
      await chrome.storage.local.remove('submittedFor');
      await setStatus('หยุดบอทแล้ว', { running: false, currentJob: null });
      return { ok: true };
    }
    if (message.type === 'CLEAR_STUCK_JOB') {
      const current = await state();
      const requestedJobId = Number(message.jobId);
      const jobId = Number.isInteger(requestedJobId) && requestedJobId > 0
        ? requestedJobId
        : Number(current.currentJob?.jobId || 0);

      // Clear only the queue/runtime state. Paid image/video checkpoints remain
      // on disk so this recovery action cannot destroy generated media.
      if (jobId > 0) {
        await api(`/api/extension/jobs/${jobId}/fail`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: 'ผู้ใช้เคลียร์งานค้างจาก Extension' }),
        });
      }
      await chrome.storage.local.remove(['submittedFor', 'nextJobCooldownUntil']);
      await setStatus(jobId > 0 ? `เคลียร์งานค้าง #${jobId} แล้ว` : 'เคลียร์สถานะบอทแล้ว — ไม่พบงานค้าง', {
        running: false,
        creditLocked: true,
        currentJob: null,
      });
      return { ok: true, jobId: jobId || null };
    }
    if (message.type === 'ADD_JOB') {
      return api('/api/extension/jobs', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          itemId: Number(message.itemId),
          durationSeconds: Number(message.durationSeconds) === 16 ? 16 : 24,
        }),
      });
    }
    if (message.type === 'FLOW_STATUS') {
      await setStatus(message.message);
      return { ok: true };
    }
    // Arm and persist the watcher BEFORE the paid Generate click. If Flow
    // re-renders the content script immediately after clicking, the background
    // still has everything required to resume after an MV3 worker restart.
    if (message.type === 'FLOW_ARM_WATCH') {
      const tabId = sender.tab?.id;
      const current = await state();
      const mediaType = message.mediaType === 'image' ? 'image' : 'video';
      if (!tabId || !current.running
        || current.currentJob?.jobId !== Number(message.jobId)
        || current.currentJob?.clipIndex !== Number(message.clipIndex)) {
        throw new Error('ไม่สามารถเริ่มตัวเฝ้าคลิปได้ เพราะงานหรือแท็บ Flow เปลี่ยนไป');
      }
      const before = Array.isArray(message.before)
        ? message.before.filter((url) => typeof url === 'string').slice(0, 200)
        : [];
      const failedBefore = Math.max(0, Number(message.failedBefore || 0));
      const existingDeadline = Number(current.currentJob.watchDeadline || 0);
      const expectedPhase = mediaType === 'image' ? 'awaitingImage' : 'awaitingVideo';
      const sameWatch = current.currentJob.phase === expectedPhase && existingDeadline > Date.now();
      const watchDeadline = sameWatch ? existingDeadline : Date.now() + FLOW_VIDEO_TIMEOUT_MS;
      const watchStartedAt = sameWatch
        ? Number(current.currentJob.watchStartedAt || Date.now())
        : Date.now();
      const armedJob = {
        ...current.currentJob,
        phase: expectedPhase,
        watchBefore: before,
        watchStartedAt,
        watchDeadline,
        watchFailedBefore: failedBefore,
      };
      await setStatus(mediaType === 'image'
        ? `งาน #${message.jobId}: เปิดตัวเฝ้าผลรูปมือจับแล้ว`
        : `งาน #${message.jobId}: เปิดตัวเฝ้าผลคลิป ${Number(message.clipIndex) + 1} แล้ว`, {
        currentJob: armedJob,
      });
      startClipWatch(tabId, Number(message.jobId), Number(message.clipIndex), before, watchDeadline, mediaType);
      return { ok: true, watchDeadline };
    }
    // Compatibility/ack after content script has clicked Generate.
    if (message.type === 'FLOW_SUBMITTED') {
      const tabId = sender.tab?.id;
      if (!tabId) return { ok: false };
      const current = await state();
      if (current.currentJob?.jobId !== Number(message.jobId)
        || current.currentJob?.clipIndex !== Number(message.clipIndex)) {
        return { ok: false, error: 'งานเปลี่ยนก่อนยืนยันการส่ง Generate' };
      }
      if (current.currentJob.phase !== 'awaitingVideo') {
        const before = Array.isArray(message.before) ? message.before : [];
        const watchDeadline = Date.now() + FLOW_VIDEO_TIMEOUT_MS;
        await setStatus(`งาน #${message.jobId}: ยืนยันการส่งสร้างคลิป ${Number(message.clipIndex) + 1}`, {
          currentJob: {
            ...current.currentJob,
            phase: 'awaitingVideo',
            watchBefore: before,
            watchStartedAt: Date.now(),
            watchDeadline,
            watchFailedBefore: Math.max(0, Number(message.failedBefore || 0)),
          },
        });
      }
      const live = await state();
      startClipWatch(
        tabId,
        Number(message.jobId),
        Number(message.clipIndex),
        Array.isArray(live.currentJob?.watchBefore) ? live.currentJob.watchBefore : [],
        Number(live.currentJob?.watchDeadline || 0)
      );
      return { ok: true };
    }
    if (message.type === 'FLOW_CLIP_READY') {
      // ต้อง catch เอง! ถ้าปล่อยให้ throw ขึ้นไป listener จะแค่ reply error กลับ
      // แล้วไม่มีใครเคลียร์ currentJob → heartbeat จะไม่เรียก runNext อีกเลย
      // (เงื่อนไขคือ running && !currentJob) = บอทค้างเงียบทั้งที่จ่าย credit ไปแล้ว
      try {
        await acceptClip({ ...message, tabId: sender.tab?.id });
      } catch (error) {
        await failCurrent(`บันทึกคลิปไม่สำเร็จ (เครดิตถูกใช้ไปแล้ว): ${error.message}`);
      }
      return { ok: true };
    }
    // ส่องเฉยๆ — เก็บ diagnostic อย่างเดียว ไม่แตะสถานะงาน
    if (message.type === 'FLOW_DIAG') {
      try {
        await api('/api/extension/diagnostic', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: message.message, url: message.url, ui: message.ui }),
        });
      } catch (_) {}
      return { ok: true };
    }
    if (message.type === 'FLOW_ERROR') {
      // ส่งภาพ DOM ตอนพังไปเก็บที่ service ก่อน — เอาไว้ไล่ selector ทีหลัง
      if (message.ui) {
        try {
          await api('/api/extension/diagnostic', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: message.message, url: message.url, ui: message.ui }),
          });
        } catch (_) { /* เก็บ diagnostic ไม่ได้ก็ต้อง fail งานต่อไปอยู่ดี */ }
      }
      await failCurrent(message.message || 'Flow ทำงานไม่สำเร็จ');
      return { ok: true };
    }
    return { ok: false };
  })().then(reply).catch((error) => {
    emitLog('error', 'message.handler', `จัดการคำสั่ง ${message?.type || 'UNKNOWN'} ไม่สำเร็จ`, { error });
    reply({ ok: false, error: error.message });
  });
  return true;
});
