(() => {
if (globalThis.__clipbotFlowContentInstalled) return;
globalThis.__clipbotFlowContentInstalled = true;

let working = false;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const visible = (element) => element && element.getClientRects().length > 0 && !element.disabled;

function all(selector) { return [...document.querySelectorAll(selector)].filter(visible); }
function byText(selector, pattern) {
  return all(selector).find((element) => pattern.test((element.textContent || '').trim()));
}
async function waitFor(find, timeout = 30000, label = 'องค์ประกอบที่ต้องใช้') {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    const value = find();
    if (value) return value;
    await sleep(400);
  }
  throw new Error(`รอหน้าจอ Flow นานเกินกำหนด: ${label}`);
}
function notify(message) { return chrome.runtime.sendMessage({ type: 'FLOW_STATUS', message }); }

/**
 * กดปุ่มแบบ "เหมือนมนุษย์กดจริง"
 *
 * ⚠️ ห้ามใช้ element.click() กับ UI ของ Flow เด็ดขาด
 * เพราะ .click() ยิงแค่ event 'click' ตัวเดียว แต่เมนูของ Flow เปิดด้วย 'pointerdown'
 * (ยืนยันจากของจริง: กดปุ่มโมเดลด้วย .click() แล้ว DOM ไม่เปลี่ยนเลยสักตัว เมนูไม่เปิด)
 *
 * ต้องยิงครบชุด pointerdown → mousedown → pointerup → mouseup → click
 * พร้อมพิกัดกลางปุ่ม เพราะบาง component เช็ค clientX/clientY ด้วย
 */
function realClick(element) {
  const rect = element.getBoundingClientRect();
  const clientX = rect.left + rect.width / 2;
  const clientY = rect.top + rect.height / 2;
  const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX, clientY, button: 0, buttons: 1 };
  const pointer = { ...base, pointerId: 1, pointerType: 'mouse', isPrimary: true };

  element.dispatchEvent(new PointerEvent('pointerover', pointer));
  element.dispatchEvent(new PointerEvent('pointerenter', pointer));
  element.dispatchEvent(new MouseEvent('mouseover', base));
  element.dispatchEvent(new PointerEvent('pointerdown', pointer));
  element.dispatchEvent(new MouseEvent('mousedown', base));
  element.dispatchEvent(new PointerEvent('pointerup', { ...pointer, buttons: 0 }));
  element.dispatchEvent(new MouseEvent('mouseup', { ...base, buttons: 0 }));
  element.dispatchEvent(new MouseEvent('click', { ...base, buttons: 0 }));
}

async function trustedClick(element) {
  const rect = element.getBoundingClientRect();
  if (!rect.width || !rect.height) throw new Error('Generate button has no clickable area');
  const response = await chrome.runtime.sendMessage({
    type: 'TRUSTED_CLICK',
    x: rect.left + rect.width / 2,
    y: rect.top + rect.height / 2,
  });
  if (!response?.ok) throw new Error(response?.error || 'Native Generate click failed');
}

function failedGenerationCardCount() {
  return all('[role="button"]').filter((element) => {
    const label = [element.textContent, element.getAttribute('aria-label'), element.getAttribute('title')]
      .filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
    return /(?:warning.*(?:ล้มเหลว|failed)|(?:ล้มเหลว|failed).*warning)/i.test(label)
      && label.length < 600;
  }).length;
}

async function confirmGenerateAccepted(generate, failedBefore) {
  await waitFor(() => {
    if (!generate.isConnected) return true;
    if (generate.disabled || generate.getAttribute('aria-disabled') === 'true') return true;
    if (!promptAccepted()) return true;
    if (failedGenerationCardCount() > failedBefore) return true;
    return all('[role="progressbar"],[aria-busy="true"]').length > 0;
  }, 10000, 'Flow acknowledgement after Generate click');
}

/**
 * ถ่ายภาพ DOM ตอนพัง เพื่อให้รู้ว่า Flow เรนเดอร์ปุ่มเป็นอะไรจริงๆ
 *
 * จำเป็นมาก เพราะ Flow UI เปลี่ยนบ่อยและเรนเดอร์ปุ่มด้วย tag แปลกๆ
 * (เคยเจอ <div type="button">เริ่ม</div> ซึ่ง selector เดิมหาไม่เจอ)
 * ถ้าไม่มีข้อมูลนี้ต้องนั่งเดา selector ทีละตัว
 */
function snapshotUi() {
  // ต้องมี role=menuitem/menuitemradio/li ด้วย ไม่งั้นเปิดเมนูแล้วก็ยังมองไม่เห็นรายการข้างใน
  // และต้องมี video/progressbar ด้วย ไม่งั้นตอนรอผลลัพธ์จะแยกไม่ออกว่า
  // "ยังเจนอยู่" หรือ "เจนเสร็จแล้วแต่บอทมองไม่เห็น"
  const nodes = [...document.querySelectorAll(
    'button,[role="button"],div[type="button"],[aria-haspopup],[role="tab"],[role="option"],' +
    '[role="menuitem"],[role="menuitemradio"],[role="menuitemcheckbox"],[role="menu"] li,[role="listbox"] *,' +
    'video,[role="progressbar"],[role="alert"],input,textarea,[contenteditable="true"]'
  )];
  return nodes.slice(0, 120).map((el) => {
    const text = (el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 45);
    return {
      tag: el.tagName.toLowerCase(),
      type: el.getAttribute('type') || undefined,
      role: el.getAttribute('role') || undefined,
      aria: (el.getAttribute('aria-label') || '').slice(0, 35) || undefined,
      pop: el.getAttribute('aria-haspopup') || undefined,
      // ต้องรู้ว่าเมนูเปิดอยู่ไหม ไม่งั้นแยกไม่ออกว่า "กดไม่ติด" หรือ "กดติดแต่หาไม่เจอ"
      expanded: el.getAttribute('aria-expanded') || undefined,
      // สำหรับ <video> — เอาไว้ดูว่าเจนออกมาหรือยัง
      src: el.tagName === 'VIDEO' ? (el.currentSrc || el.src || '(ไม่มี src)') : undefined,
      text: text || undefined,
      shown: el.getClientRects().length > 0,
    };
  });
}

async function enterEditor(job) {
  const inProject = /\/project\//.test(location.pathname);

  // คลิปแรกของทุกงานต้องเริ่มในโปรเจกต์ใหม่เสมอ ป้องกัน state เสียจากงานก่อนหน้า
  // และป้องกัน media เก่าถูก watcher เข้าใจผิดว่าเป็นผลของงานใหม่
  if (job.clipIndex === 0 && !job.projectReady) {
    if (inProject) {
      await notify('กำลังกลับหน้ารวมโปรเจกต์เพื่อเริ่มงานใหม่');
      await chrome.runtime.sendMessage({ type: 'FLOW_RESET_TO_PROJECTS', jobId: job.jobId });
      location.href = 'https://labs.google/fx/th/tools/flow';
      await sleep(30000);
      return;
    }
    await notify('กำลังเปิดโปรเจกต์ใหม่ใน Flow');
    const button = await waitFor(() => byText('button,[role="button"]', /โปรเจ็กต์ใหม่|New project/i), 30000, 'ปุ่มโปรเจ็กต์ใหม่');
    await chrome.runtime.sendMessage({ type: 'FLOW_CREATING_PROJECT', jobId: job.jobId });
    realClick(button);
    await sleep(30000);
    return;
  }

  if (inProject) return;
  if (job.clipIndex > 0) {
    // A checkpoint can be resumed after the user switches Google accounts.
    // The old Flow project is unavailable, but continuity_N.jpg is the exact
    // last frame of the previous paid clip, so it is safe to start a new
    // project and continue from that frame without regenerating earlier clips.
    await notify(`กำลังกู้ checkpoint คลิป ${job.clipIndex + 1} ในโปรเจกต์ใหม่`);
    const resumeButton = await waitFor(
      () => byText('button,[role="button"]', /โปรเจ็กต์ใหม่|New project/i),
      30000,
      'ปุ่มโปรเจ็กต์ใหม่สำหรับกู้ checkpoint'
    );
    await chrome.runtime.sendMessage({ type: 'FLOW_CREATING_PROJECT', jobId: job.jobId });
    realClick(resumeButton);
    await sleep(30000);
    return;
  }
  await notify('กำลังเปิดโปรเจ็กต์ใหม่ใน Flow');
  const button = await waitFor(() => byText('button,[role="button"]', /โปรเจ็กต์ใหม่|New project/i), 30000, 'ปุ่มโปรเจ็กต์ใหม่');
  realClick(button);
  await waitFor(() => /\/project\//.test(location.pathname), 30000, 'หน้าโปรเจ็กต์ Flow');
  await sleep(1000);
}

/** tag ที่ Flow ใช้ทำปุ่ม — มันไม่ได้ใช้ <button> เสมอไป (เจอ <div type="button"> มาแล้ว) */
const CLICKABLE = 'button,[role="button"],div[type="button"],[aria-haspopup="dialog"],[aria-haspopup="menu"]';

/** ตัวเลือกในเมนู/ป๊อปอัปของ Flow (ยืนยันจาก DOM จริง: ปุ่มโมเดลเป็น aria-haspopup="menu") */
const MENU_ITEM = '[role="menuitem"],[role="menuitemradio"],[role="option"],[role="tab"],li,button,div[type="button"]';

/**
 * กดปุ่มที่มีป๊อปอัป "จนกว่าจะเปิดจริง" — ยืนยันด้วย aria-expanded
 *
 * ทำไมต้องวนกด: realClick ยิง pointerdown (เมนูเปิด) แล้วตามด้วย click
 * ซึ่งบาง component ตีความว่าเป็นการ toggle → ปิดกลับทันที
 * ผลคือบางรอบเปิด บางรอบปิด ทั้งที่โค้ดเดียวกัน (เจอจริงมาแล้ว)
 * เช็ค aria-expanded คือวิธีเดียวที่รู้แน่ว่าเปิดจริงหรือยัง
 */
async function openPanel(button, label, confirmOpen = null) {
  const isOpen = () => button.getAttribute('aria-expanded') === 'true'
    || (typeof confirmOpen === 'function' && Boolean(confirmOpen()));
  for (let attempt = 1; attempt <= 4; attempt++) {
    if (isOpen()) return true;
    // Flow sometimes ignores synthetic pointer events after a generated card
    // re-renders the composer. Fall back to the debugger-backed native mouse
    // click used by Generate; this produces a trusted browser interaction.
    if (attempt === 1) realClick(button);
    else await trustedClick(button);
    await sleep(600);
    if (isOpen()) return true;
    await notify(`${label} ยังไม่เปิด — กดใหม่ (${attempt}/4)`);
  }
  throw new Error(`กดแล้ว ${label} ไม่เปิด — ไม่พบแผงหรือสถานะ expanded (ดู diagnostic)`);
}

async function configureImage() {
  await notify('Preparing Flow image mode (9:16, one image)');
  const modelButton = byText(CLICKABLE, /crop_(?:9_16|16_9)|Nano Banana|Imagen|Veo/i);
  if (!modelButton) throw new Error('Image model/settings button was not found');
  const currentLabel = (modelButton.textContent || '').trim();
  await openPanel(modelButton, 'image settings', () =>
    Boolean(byText('[role="tab"]', /Image|รูปภาพ/i) && byText('[role="tab"]', /Video|วิดีโอ/i))
  );

  if (/Veo|Video|วิดีโอ/i.test(currentLabel)) {
    const imageTab = byText('[role="tab"]', /Image|รูปภาพ/i);
    if (!imageTab) throw new Error('Image tab was not found in Flow settings');
    realClick(imageTab);
    await waitFor(() => Array.from(document.querySelectorAll('[role="tab"]'))
      .find((el) => el.getAttribute('aria-selected') === 'true' && /Image|รูปภาพ/i.test((el.textContent || '').trim())),
      5000, 'Flow image mode');
  }

  const portrait = byText(MENU_ITEM, /9:16/i);
  if (portrait) { realClick(portrait); await sleep(250); }
  const oneImage = byText(MENU_ITEM, /^(?:1x|1)$/i);
  if (oneImage) { realClick(oneImage); await sleep(250); }
  document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await sleep(400);

  const selectedImageTab = Array.from(document.querySelectorAll('[role="tab"]'))
    .find((el) => el.getAttribute('aria-selected') === 'true' && /Image|รูปภาพ/i.test((el.textContent || '').trim()));
  const finalLabel = (byText(CLICKABLE, /Nano Banana|Imagen|crop_9_16/i)?.textContent || '').trim();
  if ((!selectedImageTab && !/Nano Banana|Imagen/i.test(finalLabel)) || /Veo|Video|วิดีโอ/i.test(finalLabel)) {
    throw new Error(`Flow did not enter image mode (${finalLabel || 'unknown mode'})`);
  }
}

/**
 * สลับโปรเจ็กต์ให้เป็น "โหมดวิดีโอ" ก่อนทำอะไรต่อ
 *
 * สำคัญที่สุดในไฟล์นี้: โปรเจ็กต์ Flow เปิดมาเป็นโหมดสร้าง "รูป" (Nano Banana)
 * ซึ่ง "ไม่มีปุ่ม Start frame" เพราะ Start frame เป็นฟีเจอร์ของโหมดวิดีโอ
 * ถ้าสลับโหมดไม่สำเร็จแล้วปล่อยผ่าน บอทจะไปตายตอนหาปุ่ม Start frame
 * = ตายผิดที่ ไล่หาสาเหตุไม่เจอ (เสียเวลาไปหลายรอบมาแล้ว)
 *
 * ถ้าสลับไม่ได้ต้อง throw ทันทีตรงนี้ และ "ปล่อยเมนูเปิดค้างไว้"
 * เพราะ catch ข้างนอกจะถ่ายภาพ DOM ให้ → จะได้เห็นว่าในเมนูมีโมเดลอะไรให้เลือกบ้าง
 */
async function configureVideo() {
  async function selectRequiredTab(pattern, label) {
    const tab = byText('[role="tab"]', pattern);
    if (!tab) throw new Error(`ไม่พบตัวเลือก ${label} ในการตั้งค่าวิดีโอ`);
    if (tab.getAttribute('aria-selected') !== 'true') {
      realClick(tab);
      await waitFor(
        () => tab.isConnected && tab.getAttribute('aria-selected') === 'true',
        5000,
        `Flow เลือก ${label}`
      );
    }
    return tab;
  }

  await notify('กำลังตั้งค่าวิดีโอ: เฟรม · Omni Flash · 9:16 · 1x · 8s');
  // Do not match the generic words "วิดีโอ/Video": once clip 1 exists, Flow
  // adds a sidebar "ดูวิดีโอ" button before the composer settings button.
  // The crop icon/model name is the stable signature of the real settings.
  const modelButton = byText(CLICKABLE, /crop_(?:9_16|16_9)|Nano Banana|Omni\s*Flash|Omni|Veo|Imagen/i);
  if (!modelButton) {
    throw new Error('หาปุ่มเลือกโมเดลไม่เจอ (ดู diagnostic ว่ามีปุ่มอะไรบ้าง)');
  }
  await openPanel(modelButton, 'แผงตั้งค่าโมเดล', () =>
    Boolean(byText('[role="tab"]', /Image|รูปภาพ/i) && byText('[role="tab"]', /Video|วิดีโอ/i))
  );

  await selectRequiredTab(/วิดีโอ|Video/i, 'โหมดวิดีโอ');
  await selectRequiredTab(/crop_free|เฟรม|\bFrames?\b/i, 'เฟรม');
  await selectRequiredTab(/crop_9_16|9:16/i, '9:16');
  await selectRequiredTab(/^1x$/i, '1x');
  await selectRequiredTab(/^8s$/i, '8 วินาที');

  const modelSelector = '[role="menu"] button,[role="menu"] [role="button"],[role="menu"] div[type="button"]';
  let currentModel = byText(modelSelector, /arrow_drop_down/i);
  if (!currentModel) throw new Error('ไม่พบปุ่มเลือกโมเดลวิดีโอ');
  if (!/Omni\s*Flash/i.test((currentModel.textContent || '').trim())) {
    await openPanel(currentModel, 'รายชื่อโมเดลวิดีโอ', () =>
      Boolean(byText('[role="menuitem"],[role="menuitemradio"],[role="option"]', /Omni\s*Flash/i))
    );
    const omniFlash = await waitFor(
      () => byText('[role="menuitem"],[role="menuitemradio"],[role="option"]', /Omni\s*Flash/i),
      5000,
      'ตัวเลือก Omni Flash'
    );
    realClick(omniFlash);
    currentModel = await waitFor(
      () => byText(modelSelector, /Omni\s*Flash/i),
      5000,
      'Flow ยืนยันโมเดล Omni Flash'
    );
  }

  const selectedLabels = all('[role="tab"][aria-selected="true"]')
    .map((tab) => (tab.textContent || '').trim().replace(/\s+/g, ' '));
  const requiredSelections = [
    [/วิดีโอ|Video/i, 'วิดีโอ'],
    [/crop_free|เฟรม|\bFrames?\b/i, 'เฟรม'],
    [/crop_9_16|9:16/i, '9:16'],
    [/^1x$/i, '1x'],
    [/^8s$/i, '8s'],
  ];
  const missing = requiredSelections
    .filter(([pattern]) => !selectedLabels.some((label) => pattern.test(label)))
    .map(([, label]) => label);
  if (missing.length) throw new Error(`Flow ยังไม่ได้เลือก ${missing.join(', ')} — หยุดก่อนใช้เครดิต`);

  document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await sleep(400);
  const finalLabel = (modelButton.textContent || '').trim().replace(/\s+/g, ' ');
  if (!/วิดีโอ|Video/i.test(finalLabel) || !/8s/i.test(finalLabel)
      || !/crop_9_16|9:16/i.test(finalLabel) || !/1x/i.test(finalLabel)) {
    throw new Error(`ค่าหน้าปุ่มวิดีโอไม่ตรงตามกำหนด: "${finalLabel}"`);
  }
  await notify('ตั้งค่าวิดีโอสำเร็จ: เฟรม · Omni Flash · 9:16 · 1x · 8s');
}

async function uploadStartFrame(imageUrl, fileName) {
  // ── เปิดคลังสื่อด้วยปุ่ม "+" ──
  //
  // ยืนยันจาก DOM จริง (โหมดวิดีโอ): "ไม่มีปุ่ม Start frame / เริ่ม อยู่บนหน้าเลย"
  // ปุ่ม "add_2สร้าง" (aria-haspopup="dialog") เปิด "คลังสื่อ" ที่มี
  // แท็บ ทั้งหมด/รูปภาพ/วิดีโอ/เสียง/ตัวละคร/การอัปโหลด + ปุ่ม "uploadอัปโหลดสื่อ"
  // → flow จริงคือ "อัปรูปเข้าคลังก่อน แล้วค่อยเลือกใช้" ไม่ใช่กด Start frame แล้วอัป
  await notify('เปิดคลังสื่อเพื่ออัปโหลดรูปที่ Gemini เลือก');
  const plusButton = byText(CLICKABLE, /add_2/i);
  if (plusButton) {
    await openPanel(plusButton, 'คลังสื่อ (ปุ่ม +)');
  } else {
    let startFrame = byText(CLICKABLE, /^(เริ่ม|Start)$/i);
    if (!startFrame) {
      // A filled Start frame is rendered as a thumbnail plus a Material
      // "cancel" icon. Clear only that frame and wait for the Start slot to
      // return before opening the media library for the continuation image.
      const clearStartFrame = byText('button', /^cancel$/i);
      if (clearStartFrame) {
        await notify('ล้าง Start frame เดิมก่อนใส่เฟรมต่อเนื่องของคลิปถัดไป');
        realClick(clearStartFrame);
        startFrame = await waitFor(
          () => byText(CLICKABLE, /^(เริ่ม|Start)$/i),
          5000,
          'ช่อง Start frame หลังล้างรูปเดิม'
        );
      }
    }
    if (!startFrame) throw new Error('อยู่โหมด Frames แต่ไม่พบช่อง Start frame');
    realClick(startFrame);
    await waitFor(() => all('[role="dialog"]').length, 10000, 'คลังสื่อของ Start frame');
  }

  // ── โหลดรูปจาก Local Service ──
  await notify('กำลังโหลดรูปที่ Gemini เลือก');
  // ให้ background โหลดแทน content script: Chrome บางรุ่นบล็อก/ค้าง private-network
  // fetch จาก https://labs.google ไป 127.0.0.1 แม้ CORS ถูกต้องแล้วก็ตาม
  // ใช้ callback wrapper ด้วย เพราะ Chrome บาง build คืน `undefined` จาก Promise API
  // ทั้งที่ background ส่ง response กลับมาแล้ว ทำให้บอทหยุดก่อนอัปโหลดโดยไม่มีสาเหตุจริง
  const loaded = await new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'FETCH_LOCAL_IMAGE', url: imageUrl }, (response) => {
      const runtimeError = chrome.runtime.lastError;
      if (runtimeError) return resolve({ ok: false, error: runtimeError.message });
      resolve(response);
    });
  });
  if (!loaded?.ok || !loaded.base64) {
    throw new Error(loaded?.error || 'Extension background ไม่ส่งข้อมูลรูปกลับมา');
  }
  const binary = atob(loaded.base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const file = new File([bytes], fileName, { type: loaded.contentType || 'image/jpeg' });

  // ── ยัดไฟล์เข้า input[type=file] ──
  //
  // พอเปิดคลังสื่อแล้ว input[type=file] จะ shown=true (ก่อนหน้านั้น shown=false)
  // ยัดไฟล์ตรงๆ ไม่ต้องกดปุ่ม upload เพราะการกดจะเปิด dialog เลือกไฟล์ของ OS
  // ซึ่ง automate ไม่ได้
  const input = await waitFor(
    () => document.querySelector('input[type="file"]'),
    8000,
    'ช่องอัปโหลดไฟล์ในคลังสื่อ'
  );
  const transfer = new DataTransfer();
  transfer.items.add(file);
  input.files = transfer.files;
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  await notify(`อัปโหลด ${fileName} แล้ว — รอขึ้นคลัง`);

  // ── รอรูปขึ้นคลังแล้วเลือก ──
  //
  // ⚠️ ห้าม scope หา option ภายใน [role="dialog"] เด็ดขาด
  //
  // Flow build ปัจจุบันเรนเดอร์คลังสื่อเป็น portal ที่ตัว role="option" "ไม่ได้อยู่ใต้"
  // all('[role="dialog"]')[0] (บางทีมี dialog ซ้อนหลายชั้น เช่น tooltip/hovercard
  // มาก่อน แล้ว [0] ไม่ใช่คลังสื่อ) ผลคือโค้ดเดิมคืน null ทั้งที่รูปขึ้นคลังแล้ว
  // → waitFor วนจน timeout เก้อ ทั้งที่ทุกอย่างพร้อมส่ง
  //
  // ยืนยันจาก diagnostic 2026-07-18 10:13: role=option ชื่อ "clipbot_job_5_frame_1.jpg"
  // โผล่ครบ 2 ตัว + ปุ่ม "เพิ่มไปยังพรอมต์" shown=true แต่บอทมองไม่เห็นแล้ว throw
  // "อัปโหลด...ให้เสร็จ" → หาแบบ document-wide ด้วยชื่อไฟล์ที่ unique ปลอดภัยกว่า
  const wanted = fileName.toLowerCase();
  const findUploadedOption = () =>
    all('[role="option"]').find((el) => {
      const hay = `${el.textContent || ''} ${el.getAttribute('alt') || ''} ${el.getAttribute('title') || ''}`.toLowerCase();
      return hay.includes(wanted);
    }) || null;

  const option = await waitFor(
    findUploadedOption,
    60000,
    `อัปโหลด "${fileName}" ให้ขึ้นคลังสื่อ — ดู diagnostic ว่าคลังแสดงผลยังไง`
  );
  const selected = option.getAttribute('aria-selected') === 'true'
    || option.getAttribute('data-state') === 'checked';
  if (!selected) {
    realClick(option);
    await sleep(500);
  }

  // ปุ่ม "เพิ่มไปยังพรอมต์" — หา document-wide เช่นกัน (เหตุผลเดียวกับ option)
  const hasAddButton = () =>
    all('button,[role="button"],div[type="button"]')
      .find((el) => /เพิ่มไปยังพรอมต์|Add to prompt/i.test((el.textContent || '').trim()));
  // หลังอัปโหลด Flow อาจใช้เวลาประมวลผล thumbnail/virus scan เกิน 10 วินาที
  // option ขึ้นก่อน แต่ปุ่มยืนยันตามมาทีหลัง จึงให้เวลาสูงสุด 30 วินาที
  const addToPrompt = await waitFor(hasAddButton, 30000, 'ปุ่มเพิ่มไปยังพรอมต์');
  realClick(addToPrompt);

  // ยืนยันคลังปิดด้วย "ปุ่มเพิ่มไปยังพรอมต์หายไป" แทนการเช็ค !all('[role="dialog"]')
  // — เพราะคลังอาจไม่ใช่ dialog เลย (เงื่อนไข !dialog อาจจริงตั้งแต่แรกแล้วข้ามเร็วเกิน)
  await waitFor(() => !hasAddButton(), 15000, 'คลังสื่อปิดหลังเพิ่มรูป').catch(() => null);
  await sleep(700);
  await notify('เลือกรูปเป็น Start frame แล้ว');
}

/** ปุ่มส่ง (arrow_forward) — ถ้ามันยัง disabled แปลว่า Flow ยังไม่รับ prompt */
function submitButton() {
  return all('button,[role="button"]').find((b) => {
    if (b.getAttribute('aria-haspopup')) return false;
    const text = `${b.textContent || ''} ${b.getAttribute('aria-label') || ''}`;
    return /arrow_forward/i.test(text);
  }) || null;
}

/** Flow รับ prompt แล้วจริงไหม — ดูจากปุ่มส่งว่าเลิก disabled หรือยัง */
function promptAccepted() {
  const button = submitButton();
  if (!button) return false;
  return button.getAttribute('aria-disabled') !== 'true' && !button.disabled;
}

/** เลือกข้อความในช่องทั้งหมดแล้วลบ */
function clearEditor(editor) {
  editor.focus();
  const range = document.createRange();
  range.selectNodeContents(editor);
  const selection = window.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
  document.execCommand('delete', false);
}

/**
 * ใส่ Motion Prompt ลงช่องของ Flow
 *
 * ⚠️ ห้ามยัดข้อความเข้า DOM ตรงๆ (editor.value = x หรือ textContent = x)
 *
 * ช่อง prompt ของ Flow เป็น contenteditable ที่เก็บ state ไว้ข้างในตัวเอง (Lexical)
 * การยัด DOM ตรงๆ ทำให้ "ตาเห็นข้อความ แต่ editor ไม่รู้จัก" ผลคือ:
 *   - กด Generate แล้ว Flow ฟ้อง "ต้องระบุพรอมต์"
 *   - ปุ่มส่งยัง disabled (สีดำ)
 *   - ลบข้อความนั้นด้วยมือไม่ได้ เพราะ editor ไม่รู้ว่ามีอยู่
 * (ยืนยันจากผู้ใช้ทดสอบด้วยมือเอง — วางเองแล้วใช้ได้ แต่ของบอทใช้ไม่ได้)
 *
 * ต้องจำลอง "การวาง" ให้ editor ประมวลผลเอง แล้วยืนยันด้วยปุ่มส่งว่าติดจริง
 */
async function fillPrompt(prompt) {
  await notify('กำลังใส่ Motion Prompt ใน Flow');
  const editor = await waitFor(() =>
    all('textarea,[role="textbox"],[contenteditable="true"]').find((element) =>
      !element.closest('[aria-hidden="true"]')
    ), 15000, 'ช่อง Motion Prompt');

  // ช่องแบบ <textarea>/<input> จริงๆ — ต้องยิงผ่าน native setter ให้ React เห็น
  // Flow's Lexical editor accepts real keyboard input, not synthetic paste/DOM injection.
  editor.focus();
  const typed = await chrome.runtime.sendMessage({ type: 'TYPE_PROMPT', prompt });
  if (!typed?.ok) throw new Error(typed?.error || 'Keyboard typing failed');
  await waitFor(promptAccepted, 10000, 'Generate button after keyboard typing');
  await notify('Motion Prompt typed character-by-character; Generate is enabled');
  return;

  const nativeInput = (element, value) => {
    const proto = element instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    setter ? setter.call(element, value) : (element.value = value);
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  };

  const strategies = [
    // 1) จำลองการวาง (paste) — ผู้ใช้ยืนยันว่าวางเองแล้ว Flow รับ
    {
      name: 'paste',
      run: () => {
        clearEditor(editor);
        const data = new DataTransfer();
        data.setData('text/plain', prompt);
        editor.dispatchEvent(new ClipboardEvent('paste', {
          bubbles: true, cancelable: true, clipboardData: data,
        }));
      },
    },
    // 2) beforeinput แบบ insertFromPaste — Lexical/ProseMirror ฟัง event นี้โดยตรง
    {
      name: 'beforeinput',
      run: () => {
        clearEditor(editor);
        const data = new DataTransfer();
        data.setData('text/plain', prompt);
        editor.dispatchEvent(new InputEvent('beforeinput', {
          bubbles: true, cancelable: true, inputType: 'insertFromPaste', dataTransfer: data,
        }));
      },
    },
    // 3) execCommand — ให้เบราว์เซอร์เป็นคนแทรกเอง (จะยิง beforeinput/input ให้ครบ)
    {
      name: 'execCommand',
      run: () => {
        clearEditor(editor);
        document.execCommand('insertText', false, prompt);
      },
    },
    // 4) native setter — สำหรับกรณีที่เป็น textarea/input จริง
    {
      name: 'nativeSetter',
      run: () => { if ('value' in editor) nativeInput(editor, prompt); },
    },
  ];

  for (const strategy of strategies) {
    strategy.run();
    await sleep(700);
    if (promptAccepted()) {
      await notify(`ใส่ prompt สำเร็จ (วิธี: ${strategy.name})`);
      return;
    }
    await notify(`วิธี "${strategy.name}" ไม่ติด — ลองวิธีถัดไป`);
  }

  throw new Error(
    'ใส่ prompt แล้วปุ่มส่งยัง disabled — Flow ไม่รับ prompt (ลองครบทุกวิธีแล้ว) — ดู diagnostic'
  );
}

function videoUrls() {
  const found = new Map();
  const nodes = document.querySelectorAll(
    'video,source,img[src*="getMediaUrlRedirect"]'
  );
  for (const node of nodes) {
    const raw = node.currentSrc || node.getAttribute('src') || '';
    if (!raw) continue;
    let url;
    try { url = new URL(raw, location.href).href; } catch (_) { continue; }
    const card = node.closest('a,button,[role="button"]') || node.parentElement;
    const label = [
      card?.textContent,
      card?.getAttribute?.('aria-label'),
      node.getAttribute?.('aria-label'),
      node.getAttribute?.('alt'),
    ].filter(Boolean).join(' ');
    const isVideo = /^(VIDEO|SOURCE)$/.test(node.tagName)
      || Boolean(card?.querySelector?.('video,source'))
      || /play_circle|videocam|video|วิดีโอ/i.test(label);
    if (!isVideo) continue;
    let key = url;
    try { key = new URL(url).searchParams.get('name') || url; } catch (_) {}
    const priority = /^(VIDEO|SOURCE)$/.test(node.tagName)
      ? 3
      : /mediaUrlType=MEDIA_URL_TYPE_THUMBNAIL/i.test(url)
        ? 1
        : 2;
    const previous = found.get(key);
    if (!previous || priority > previous.priority) {
      found.set(key, { url, priority });
    }
  }
  return [...found.values()].map((item) => item.url);
}

function imageUrls() {
  const found = new Map();
  for (const node of document.querySelectorAll('img[src*="getMediaUrlRedirect"]')) {
    const raw = node.currentSrc || node.getAttribute('src') || '';
    if (!raw) continue;
    if (node.naturalWidth && node.naturalWidth < 128) continue;
    if (node.naturalHeight && node.naturalHeight < 128) continue;
    let url;
    try { url = new URL(raw, location.href).href; } catch (_) { continue; }
    let key = url;
    try { key = new URL(url).searchParams.get('name') || url; } catch (_) {}
    const priority = /mediaUrlType=MEDIA_URL_TYPE_THUMBNAIL/i.test(url) ? 1 : 2;
    const previous = found.get(key);
    if (!previous || priority > previous.priority) found.set(key, { url, priority });
  }
  return [...found.values()].map((item) => item.url);
}

/**
 * ตรวจว่าหน้า Flow crash หรือยัง (React error boundary ของ Next.js)
 *
 * labs.google เป็น Labs beta พังเองบ่อย โดยเฉพาะตอนโหลดหนักๆ หรือ session ใกล้หมด
 * ขึ้นข้อความ "Application error: a client-side exception has occurred"
 * ถ้าไม่กันไว้ บอทจะไปหาปุ่มบนหน้าที่พังแล้ว timeout ตายทั้งที่แค่ refresh ก็หาย
 */
function isFlowCrashed() {
  const text = document.body?.innerText || '';
  return /client-side exception has occurred|Application error:/i.test(text);
}

/**
 * กู้หน้าที่ crash ด้วยการ reload — แต่กัน reload วนไม่รู้จบ
 *
 * reload แล้ว content script ตาย → background (chrome.tabs.onUpdated) จะ re-inject
 * แล้วส่งงานเดิมกลับมาให้ทำต่อเอง ถ้า reload แล้วยัง crash อีก = ปัญหาจริง (session หมด?)
 * ต้องหยุดแล้วบอกคน ไม่ใช่ reload ไปเรื่อยๆ
 */
async function recoverIfCrashed() {
  const KEY = 'clipbotReloadCount';
  if (!isFlowCrashed()) {
    // หน้าปกติ = คืน budget reload ให้เต็ม เผื่อ crash รอบหน้า
    sessionStorage.removeItem(KEY);
    return false;
  }

  const count = Number(sessionStorage.getItem(KEY) || '0');
  if (count >= 2) {
    // reload 2 ครั้งแล้วยัง crash — session น่าจะหมด ต้อง login ใหม่
    throw new Error('หน้า Flow crash ซ้ำหลัง reload 2 ครั้ง — น่าจะ session หมดอายุ ต้อง login Google ใหม่');
  }
  sessionStorage.setItem(KEY, String(count + 1));
  await notify(`หน้า Flow crash — กำลัง refresh กู้อัตโนมัติ (ครั้งที่ ${count + 1})`);
  await sleep(500);
  location.reload();
  await sleep(10000); // รอ reload — content script จะตายระหว่างนี้
  return true;
}

async function generateImage(job) {
  if (working) return;
  working = true;
  try {
    if (await recoverIfCrashed()) return;
    await notify(`Job #${job.jobId}: preparing the hand-held product image`);
    await enterEditor(job);
    await configureImage();
    await uploadStartFrame(job.imageUrl, `clipbot_job_${job.jobId}_product_reference.jpg`);
    await fillPrompt(job.prompt);
    const before = new Set(imageUrls());
    // Flow resolves an uploaded asset through several redirect URLs. Merge a
    // second snapshot so a late-settling reference URL cannot look like output.
    await sleep(1200);
    for (const url of imageUrls()) before.add(url);
    const failedBefore = failedGenerationCardCount();
    const generate = await waitFor(() =>
      all('button,[role="button"]').find((button) => {
        if (button.getAttribute('aria-haspopup')) return false;
        if (button.getAttribute('aria-disabled') === 'true' || button.disabled) return false;
        const text = `${button.textContent || ''} ${button.getAttribute('aria-label') || ''}`;
        return /arrow_forward|^\s*Generate\b/i.test(text);
      }), 15000, 'image Generate button');
    const armed = await chrome.runtime.sendMessage({
      type: 'FLOW_ARM_WATCH',
      mediaType: 'image',
      jobId: job.jobId,
      clipIndex: 0,
      before: [...before],
      failedBefore,
    });
    if (!armed?.ok) throw new Error(armed?.error || 'Could not arm the generated-image watcher');
    await trustedClick(generate);
    await confirmGenerateAccepted(generate, failedBefore);
    await notify(`Job #${job.jobId}: image generation submitted — duplicate clicks are blocked`);
  } catch (error) {
    await chrome.runtime.sendMessage({
      type: 'FLOW_ERROR',
      message: error.message,
      url: location.href,
      ui: snapshotUi(),
    });
  } finally {
    working = false;
  }
}

async function generateClip(job) {
  if (working) return;
  working = true;
  try {
    // กู้ก่อนถ้าหน้า crash — ถ้า reload มันจะ return แล้ว background ส่งงานกลับมาใหม่หลังโหลดเสร็จ
    if (await recoverIfCrashed()) return;

    await notify(`งาน #${job.jobId}: เตรียมคลิป ${job.clipIndex + 1} จาก ${job.clipCount || 3}`);
    await enterEditor(job);
    await configureVideo();
    await uploadStartFrame(job.imageUrl, `clipbot_job_${job.jobId}_frame_${job.clipIndex + 1}.jpg`);
    await fillPrompt(job.prompt);
    const before = new Set(videoUrls());
    const failedBefore = failedGenerationCardCount();
    await notify(`งาน #${job.jobId}: พร้อมกดสร้างคลิป ${job.clipIndex + 1}`);
    // ⚠️ ห้ามจับด้วยคำว่า "สร้าง" เฉยๆ เด็ดขาด!
    //
    // DOM จริงมีปุ่มที่ข้อความลงท้ายด้วย "สร้าง" อยู่ 2 ตัว และตัวที่มาก่อนคือปุ่มผิด:
    //   1. "add_2สร้าง"          (aria-haspopup="dialog") = ปุ่ม + เปิดคลังสื่อ  ← .find() คว้าตัวนี้
    //   2. "arrow_forwardสร้าง"  (ไม่มี haspopup)          = ปุ่มส่งตัวจริง
    // ผลคือบอทกดปุ่ม + แล้วรอวิดีโอ 6 นาทีเก้อ ทั้งที่ไม่เคยส่งอะไรเลย
    //
    // "arrow_forward" คือไอคอนของปุ่มส่งโดยเฉพาะ ใช้เป็นตัวจับได้แม่นกว่า
    // และตัดปุ่มที่เปิดป๊อปอัปทิ้งไปเลย เพราะปุ่มส่งไม่มีทางเปิดป๊อปอัป
    const generate = await waitFor(() =>
      all('button,[role="button"]').find((button) => {
        if (button.getAttribute('aria-haspopup')) return false;
        if (button.getAttribute('aria-disabled') === 'true' || button.disabled) return false;
        const text = `${button.textContent || ''} ${button.getAttribute('aria-label') || ''}`;
        return /arrow_forward|^\s*Generate\b|^\s*สร้างวิดีโอ/i.test(text);
      }), 15000, 'ปุ่มส่ง (arrow_forward)');
    // Persist the watcher checkpoint before the paid click. Flow can re-render
    // this page immediately after Generate; arming afterwards creates a race
    // where the click succeeds but nobody ever observes the resulting video.
    const armed = await chrome.runtime.sendMessage({
      type: 'FLOW_ARM_WATCH',
      mediaType: 'video',
      jobId: job.jobId,
      clipIndex: job.clipIndex,
      before: [...before],
      failedBefore,
    });
    if (!armed?.ok) throw new Error(armed?.error || 'เปิดตัวเฝ้าผลวิดีโอไม่สำเร็จ — ยังไม่ได้กด Generate');

    await trustedClick(generate);
    await confirmGenerateAccepted(generate, failedBefore);
    await notify(`งาน #${job.jobId}: ส่งสร้างคลิป ${job.clipIndex + 1} แล้ว — จะไม่กดซ้ำ`);

    // background already owns the durable watcher; content script can now be
    // destroyed/re-rendered without losing the paid result.
  } catch (error) {
    // แนบภาพ DOM ไปด้วยเสมอ — เวลาพังจะได้รู้ทันทีว่า Flow เรนเดอร์อะไรอยู่
    // ไม่ต้องให้คนไปเปิด DevTools ไล่ดูเอง
    await chrome.runtime.sendMessage({
      type: 'FLOW_ERROR',
      message: error.message,
      url: location.href,
      ui: snapshotUi(),
    });
  } finally {
    working = false;
  }
}

function mountFloatingControl() {
  if (document.getElementById('clipbot-floating-control')) return;

  const host = document.createElement('div');
  host.id = 'clipbot-floating-control';
  host.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483600;';
  const shadow = host.attachShadow({ mode: 'open' });
  const iconUrl = chrome.runtime.getURL('icons/icon32.png');
  shadow.innerHTML = `
    <style>
      :host {
        --cb-bg: hsl(214 46% 9%);
        --cb-panel: hsl(213 42% 12%);
        --cb-soft: hsl(212 31% 17%);
        --cb-line: hsl(210 27% 28%);
        --cb-text: hsl(210 40% 97%);
        --cb-muted: hsl(211 18% 67%);
        --cb-red: hsl(1 93% 65%);
        --cb-green: hsl(151 70% 56%);
        --cb-amber: hsl(39 92% 62%);
        font-family: "Noto Sans Thai", "Leelawadee UI", "Segoe UI", sans-serif;
        color: var(--cb-text);
        -webkit-font-smoothing: antialiased;
        text-rendering: optimizeLegibility;
      }
      * { box-sizing: border-box; }
      button { font: inherit; }
      button:focus-visible {
        outline: 3px solid hsl(196 90% 60% / .9);
        outline-offset: 2px;
      }
      .fab {
        min-width: 56px;
        height: 56px;
        padding: 0 16px;
        border: 1px solid hsl(1 93% 68% / .65);
        border-radius: 18px;
        color: white;
        background: hsl(214 46% 9% / .96);
        box-shadow: 0 2px 5px hsl(220 50% 2% / .34), 0 12px 32px hsl(220 50% 2% / .5);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 9px;
        cursor: pointer;
        transition: transform 120ms cubic-bezier(.23,1,.32,1), border-color 120ms, background-color 120ms;
      }
      .fab:active, .action:active, .icon-button:active { transform: scale(.97); }
      .fab-mark {
        width: 28px;
        height: 28px;
        border-radius: 9px;
        display: grid;
        place-items: center;
        overflow: hidden;
        background: hsl(214 46% 9%);
      }
      .fab-mark img { width: 100%; height: 100%; display: block; object-fit: cover; }
      .fab-label { font-size: 14px; font-weight: 750; letter-spacing: -.01em; }
      .panel {
        position: absolute;
        right: 0;
        bottom: 68px;
        width: min(328px, calc(100vw - 24px));
        padding: 8px;
        border: 1px solid hsl(210 27% 30% / .82);
        border-radius: 22px;
        background: hsl(214 46% 8% / .97);
        box-shadow: 0 4px 12px hsl(220 50% 2% / .32), 0 24px 64px hsl(220 50% 2% / .62);
        transform-origin: right bottom;
        transition: opacity 180ms cubic-bezier(.23,1,.32,1), transform 180ms cubic-bezier(.23,1,.32,1);
        backdrop-filter: blur(18px);
      }
      .panel[hidden] { display: block; opacity: 0; transform: translateY(8px) scale(.96); pointer-events: none; }
      .panel-card { border-radius: 14px; background: var(--cb-panel); overflow: hidden; }
      .header {
        min-height: 64px;
        padding: 12px 12px 12px 14px;
        display: flex;
        align-items: center;
        gap: 11px;
        border-bottom: 1px solid var(--cb-line);
      }
      .brand { flex: 1; min-width: 0; }
      .title { font-size: 16px; line-height: 1.2; font-weight: 780; letter-spacing: -.02em; }
      .eyebrow { margin-top: 3px; color: var(--cb-muted); font-size: 11px; font-weight: 650; letter-spacing: .08em; text-transform: uppercase; }
      .icon-button {
        width: 44px;
        height: 44px;
        border: 0;
        border-radius: 12px;
        color: var(--cb-muted);
        background: transparent;
        cursor: pointer;
      }
      .status-wrap { padding: 14px; }
      .state-row { display: flex; align-items: center; gap: 8px; margin-bottom: 9px; }
      .dot { width: 9px; height: 9px; border-radius: 999px; background: var(--cb-muted); box-shadow: 0 0 0 4px hsl(211 18% 67% / .1); }
      .dot.running { background: var(--cb-green); box-shadow: 0 0 0 4px hsl(151 70% 56% / .12); }
      .dot.locked { background: var(--cb-amber); box-shadow: 0 0 0 4px hsl(39 92% 62% / .12); }
      .state-label { font-size: 13px; font-weight: 720; }
      .job { margin-left: auto; color: var(--cb-muted); font-size: 12px; font-variant-numeric: tabular-nums; }
      .message { min-height: 42px; color: hsl(210 28% 88%); font-size: 13px; line-height: 1.55; text-wrap: pretty; }
      .cooldown {
        margin-top: 11px;
        padding: 10px 11px;
        display: grid;
        grid-template-columns: 1fr auto;
        align-items: center;
        gap: 3px 12px;
        border: 1px solid hsl(39 58% 37% / .72);
        border-radius: 12px;
        background: linear-gradient(135deg, hsl(39 64% 18% / .68), hsl(213 42% 14%));
      }
      .cooldown[hidden] { display: none; }
      .cooldown-label { color: hsl(40 60% 78%); font-size: 11px; font-weight: 650; }
      .cooldown-target { color: hsl(210 35% 94%); font-size: 12px; font-weight: 720; }
      .cooldown-time { grid-row: 1 / 3; grid-column: 2; color: hsl(40 95% 72%); font-size: 25px; line-height: 1; font-weight: 820; letter-spacing: .04em; font-variant-numeric: tabular-nums; }
      .safety {
        margin-top: 11px;
        padding: 9px 10px;
        border-radius: 10px;
        color: hsl(40 95% 82%);
        background: hsl(39 64% 18% / .62);
        font-size: 12px;
        line-height: 1.45;
      }
      .safety[hidden] { display: none; }
      .actions { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; padding: 0 14px 14px; }
      .action {
        min-height: 44px;
        border: 1px solid var(--cb-line);
        border-radius: 12px;
        color: var(--cb-text);
        background: var(--cb-soft);
        font-size: 13px;
        font-weight: 720;
        cursor: pointer;
        transition: transform 120ms cubic-bezier(.23,1,.32,1), background-color 120ms, opacity 120ms;
      }
      .action.primary { border-color: hsl(1 93% 68% / .7); background: var(--cb-red); color: hsl(214 46% 8%); }
      .action.wide { grid-column: 1 / -1; }
      .action:disabled { opacity: .42; cursor: not-allowed; }
      .notice { padding: 0 14px 13px; color: hsl(1 92% 80%); font-size: 12px; line-height: 1.45; }
      .notice:empty { display: none; }
      @media (hover:hover) and (pointer:fine) {
        .fab:hover { background: hsl(213 42% 13% / .98); border-color: var(--cb-red); }
        .action:not(:disabled):hover { background: hsl(211 30% 22%); }
        .action.primary:not(:disabled):hover { background: hsl(1 93% 70%); }
        .icon-button:hover { color: var(--cb-text); background: var(--cb-soft); }
      }
      @media (prefers-reduced-motion: reduce) {
        .fab, .panel, .action, .icon-button { transition-duration: .01ms !important; }
      }
    </style>
    <section class="panel" id="panel" role="dialog" aria-labelledby="clipbot-float-title">
      <div class="panel-card">
        <header class="header">
          <span class="fab-mark" aria-hidden="true"><img src="${iconUrl}" alt=""></span>
          <div class="brand">
            <div class="title" id="clipbot-float-title">ClipForge</div>
            <div class="eyebrow">Chrome bot control</div>
          </div>
          <button class="icon-button" id="close" type="button" aria-label="ย่อแผง ClipForge">✕</button>
        </header>
        <div class="status-wrap">
          <div class="state-row">
            <span class="dot" id="dot" aria-hidden="true"></span>
            <span class="state-label" id="state">กำลังเชื่อมต่อ…</span>
            <span class="job" id="job"></span>
          </div>
          <div class="message" id="message" aria-live="polite">กำลังอ่านสถานะบอท</div>
          <div class="cooldown" id="cooldown" hidden aria-live="polite">
            <span class="cooldown-label">⏱ คูลดาวน์</span>
            <span class="cooldown-target" id="cooldown-target">พักก่อนคลิปถัดไป</span>
            <time class="cooldown-time" id="cooldown-time" datetime="PT0S">00:00</time>
          </div>
          <div class="safety" id="safety" hidden>🔒 เครดิตถูกล็อก บอทจะไม่กด Generate</div>
        </div>
        <div class="actions">
          <button class="action primary" id="start" type="button">▶ เริ่มบอท</button>
          <button class="action" id="stop" type="button">■ หยุด</button>
          <button class="action wide" id="lock" type="button">ปลดล็อกเครดิต</button>
        </div>
        <div class="notice" id="notice" aria-live="polite"></div>
      </div>
    </section>
    <button class="fab" id="fab" type="button" aria-expanded="true" aria-controls="panel">
      <span class="fab-mark" aria-hidden="true"><img src="${iconUrl}" alt=""></span>
      <span class="fab-label">ClipForge</span>
    </button>`;

  const panel = shadow.getElementById('panel');
  const fab = shadow.getElementById('fab');
  const close = shadow.getElementById('close');
  const dot = shadow.getElementById('dot');
  const stateLabel = shadow.getElementById('state');
  const jobLabel = shadow.getElementById('job');
  const message = shadow.getElementById('message');
  const cooldownPanel = shadow.getElementById('cooldown');
  const cooldownTarget = shadow.getElementById('cooldown-target');
  const cooldownTime = shadow.getElementById('cooldown-time');
  const safety = shadow.getElementById('safety');
  const start = shadow.getElementById('start');
  const stop = shadow.getElementById('stop');
  const lock = shadow.getElementById('lock');
  const notice = shadow.getElementById('notice');
  let latest = null;
  let busy = false;
  let announcedCooldownUntil = 0;

  function setOpen(open) {
    panel.hidden = !open;
    fab.setAttribute('aria-expanded', String(open));
    if (open) close.focus({ preventScroll: true });
    else fab.focus({ preventScroll: true });
  }

  function showNotice(text) { notice.textContent = text || ''; }

  function renderFloatingCooldown() {
    const now = Date.now();
    const clipUntil = Number(latest?.currentJob?.cooldownUntil || 0);
    const nextJobUntil = Number(latest?.nextJobCooldownUntil || 0);
    let until = 0;
    let target = '';
    if (clipUntil > now) {
      until = clipUntil;
      const clipCount = Number(latest.currentJob?.clipCount || 3);
      const nextClip = Math.min(clipCount, Number(latest.currentJob?.clipIndex || 0) + 1);
      target = `พักก่อนคลิป ${nextClip} จาก ${clipCount}`;
    } else if (nextJobUntil > now) {
      until = nextJobUntil;
      target = 'พักก่อนเริ่มงานถัดไป';
    }
    cooldownPanel.hidden = !until;
    if (!until) return;
    const totalSeconds = Math.max(0, Math.ceil((until - now) / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    cooldownTarget.textContent = target;
    cooldownTime.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    cooldownTime.dateTime = `PT${totalSeconds}S`;
  }

  function revealNewCooldown() {
    const now = Date.now();
    const clipUntil = Number(latest?.currentJob?.cooldownUntil || 0);
    const nextJobUntil = Number(latest?.nextJobCooldownUntil || 0);
    const activeUntil = clipUntil > now ? clipUntil : (nextJobUntil > now ? nextJobUntil : 0);
    if (!activeUntil) {
      announcedCooldownUntil = 0;
      return;
    }
    if (activeUntil === announcedCooldownUntil) return;
    announcedCooldownUntil = activeUntil;
    panel.hidden = false;
    fab.setAttribute('aria-expanded', 'true');
  }

  async function refreshFloatingStatus() {
    try {
      const bot = await chrome.runtime.sendMessage({ type: 'GET_STATUS' });
      latest = bot;
      renderFloatingCooldown();
      revealNewCooldown();
      dot.className = `dot ${bot.running ? 'running' : (bot.creditLocked ? 'locked' : '')}`;
      stateLabel.textContent = bot.running ? 'บอทกำลังทำงาน' : (bot.creditLocked ? 'ล็อกเครดิตอยู่' : 'พร้อมเริ่ม');
      jobLabel.textContent = bot.currentJob?.jobId
        ? (bot.currentJob.stage === 'image'
          ? `งาน #${bot.currentJob.jobId} · กำลังสร้างรูปมือจับ`
          : `งาน #${bot.currentJob.jobId} · คลิป ${(bot.currentJob.clipIndex || 0) + 1}/${bot.currentJob.clipCount || 3}`)
        : '';
      message.textContent = bot.lastStatus || 'บอทหยุดอยู่';
      safety.hidden = !bot.creditLocked;
      start.disabled = busy || bot.creditLocked || bot.running;
      stop.disabled = busy || !bot.running;
      lock.disabled = busy;
      lock.textContent = bot.creditLocked ? 'ปลดล็อกเครดิต' : '🔒 ล็อกเครดิตและหยุด';
      fab.title = stateLabel.textContent;
    } catch (_) {
      latest = null;
      renderFloatingCooldown();
      dot.className = 'dot';
      stateLabel.textContent = 'Extension ไม่ตอบสนอง';
      message.textContent = 'รีเฟรชหน้า Flow หลังโหลด Extension เวอร์ชันใหม่';
      start.disabled = true;
      stop.disabled = true;
      lock.disabled = true;
    }
  }

  async function runAction(action) {
    if (busy) return;
    busy = true;
    showNotice('');
    await refreshFloatingStatus();
    try {
      const result = await action();
      if (result?.ok === false) throw new Error(result.error || 'คำสั่งไม่สำเร็จ');
    } catch (error) {
      showNotice(error?.message || String(error));
    } finally {
      busy = false;
      await refreshFloatingStatus();
    }
  }

  fab.addEventListener('click', () => setOpen(panel.hidden));
  close.addEventListener('click', () => setOpen(false));
  start.addEventListener('click', () => runAction(() => chrome.runtime.sendMessage({
    type: 'START',
    durationSeconds: latest?.durationSeconds || 24,
  })));
  stop.addEventListener('click', () => runAction(() => chrome.runtime.sendMessage({ type: 'STOP' })));
  lock.addEventListener('click', () => runAction(async () => {
    const unlocking = latest?.creditLocked !== false;
    if (unlocking && !window.confirm('ปลดล็อกเครดิตและอนุญาตให้ ClipForge กดสร้างวิดีโอจริงหรือไม่?')) {
      return { ok: true };
    }
    return chrome.runtime.sendMessage({ type: 'SET_LOCK', locked: !unlocking });
  }));
  shadow.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !panel.hidden) setOpen(false);
  });

  const firstOpen = sessionStorage.getItem('clipbotFloatingSeen') !== '1';
  sessionStorage.setItem('clipbotFloatingSeen', '1');
  panel.hidden = !firstOpen;
  fab.setAttribute('aria-expanded', String(firstOpen));
  document.documentElement.appendChild(host);
  refreshFloatingStatus();
  setInterval(refreshFloatingStatus, 2500);
  setInterval(renderFloatingCooldown, 250);
}

chrome.runtime.onMessage.addListener((message, _sender, reply) => {
  // ถ่าย DOM ตามคำสั่ง — ไม่แตะอะไรบนหน้า ใช้ส่องตอนบอทค้าง
  if (message.type === 'FLOW_SNAPSHOT') {
    // ใช้ FLOW_DIAG ไม่ใช่ FLOW_ERROR — ไม่งั้นจะไปสั่ง failCurrent ทำ job พังทั้งที่แค่ส่อง
    chrome.runtime.sendMessage({
      type: 'FLOW_DIAG',
      message: `[SNAPSHOT ตามคำสั่ง] content script ยังทำงานอยู่ไหม: working=${working}`,
      url: location.href,
      ui: snapshotUi(),
    });
    reply({ ok: true });
    return;
  }
  if (!['FLOW_RUN_IMAGE', 'FLOW_RUN_CLIP'].includes(message.type)) return;
  if (message.type === 'FLOW_RUN_IMAGE') generateImage(message);
  else generateClip(message);
  reply({ ok: true });
});
mountFloatingControl();
})();
